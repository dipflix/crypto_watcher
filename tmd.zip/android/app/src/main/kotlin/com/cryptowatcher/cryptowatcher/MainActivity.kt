package com.cryptowatcher.cryptowatcher

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
