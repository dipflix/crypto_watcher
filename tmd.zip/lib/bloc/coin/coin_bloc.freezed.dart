// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'coin_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CoinEvent {
  int get id => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int id) getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int id)? getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int id)? getMarketCoins,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CoinEvent_OnGetCoin value) getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CoinEvent_OnGetCoin value)? getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CoinEvent_OnGetCoin value)? getMarketCoins,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CoinEventCopyWith<CoinEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CoinEventCopyWith<$Res> {
  factory $CoinEventCopyWith(CoinEvent value, $Res Function(CoinEvent) then) =
      _$CoinEventCopyWithImpl<$Res, CoinEvent>;
  @useResult
  $Res call({int id});
}

/// @nodoc
class _$CoinEventCopyWithImpl<$Res, $Val extends CoinEvent>
    implements $CoinEventCopyWith<$Res> {
  _$CoinEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CoinEvent_OnGetCoinCopyWith<$Res>
    implements $CoinEventCopyWith<$Res> {
  factory _$$CoinEvent_OnGetCoinCopyWith(_$CoinEvent_OnGetCoin value,
          $Res Function(_$CoinEvent_OnGetCoin) then) =
      __$$CoinEvent_OnGetCoinCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int id});
}

/// @nodoc
class __$$CoinEvent_OnGetCoinCopyWithImpl<$Res>
    extends _$CoinEventCopyWithImpl<$Res, _$CoinEvent_OnGetCoin>
    implements _$$CoinEvent_OnGetCoinCopyWith<$Res> {
  __$$CoinEvent_OnGetCoinCopyWithImpl(
      _$CoinEvent_OnGetCoin _value, $Res Function(_$CoinEvent_OnGetCoin) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
  }) {
    return _then(_$CoinEvent_OnGetCoin(
      null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$CoinEvent_OnGetCoin implements CoinEvent_OnGetCoin {
  const _$CoinEvent_OnGetCoin(this.id);

  @override
  final int id;

  @override
  String toString() {
    return 'CoinEvent.getMarketCoins(id: $id)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CoinEvent_OnGetCoin &&
            (identical(other.id, id) || other.id == id));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CoinEvent_OnGetCoinCopyWith<_$CoinEvent_OnGetCoin> get copyWith =>
      __$$CoinEvent_OnGetCoinCopyWithImpl<_$CoinEvent_OnGetCoin>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int id) getMarketCoins,
  }) {
    return getMarketCoins(id);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int id)? getMarketCoins,
  }) {
    return getMarketCoins?.call(id);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int id)? getMarketCoins,
    required TResult orElse(),
  }) {
    if (getMarketCoins != null) {
      return getMarketCoins(id);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CoinEvent_OnGetCoin value) getMarketCoins,
  }) {
    return getMarketCoins(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CoinEvent_OnGetCoin value)? getMarketCoins,
  }) {
    return getMarketCoins?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CoinEvent_OnGetCoin value)? getMarketCoins,
    required TResult orElse(),
  }) {
    if (getMarketCoins != null) {
      return getMarketCoins(this);
    }
    return orElse();
  }
}

abstract class CoinEvent_OnGetCoin implements CoinEvent {
  const factory CoinEvent_OnGetCoin(final int id) = _$CoinEvent_OnGetCoin;

  @override
  int get id;
  @override
  @JsonKey(ignore: true)
  _$$CoinEvent_OnGetCoinCopyWith<_$CoinEvent_OnGetCoin> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$CoinState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(CoinFullModel coinModel) ready,
    required TResult Function(Object? error) error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(CoinFullModel coinModel)? ready,
    TResult? Function(Object? error)? error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(CoinFullModel coinModel)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CoinState_loading value) loading,
    required TResult Function(CoinState_Ready value) ready,
    required TResult Function(CoinState_Error value) error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CoinState_loading value)? loading,
    TResult? Function(CoinState_Ready value)? ready,
    TResult? Function(CoinState_Error value)? error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CoinState_loading value)? loading,
    TResult Function(CoinState_Ready value)? ready,
    TResult Function(CoinState_Error value)? error,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CoinStateCopyWith<$Res> {
  factory $CoinStateCopyWith(CoinState value, $Res Function(CoinState) then) =
      _$CoinStateCopyWithImpl<$Res, CoinState>;
}

/// @nodoc
class _$CoinStateCopyWithImpl<$Res, $Val extends CoinState>
    implements $CoinStateCopyWith<$Res> {
  _$CoinStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$CoinState_loadingCopyWith<$Res> {
  factory _$$CoinState_loadingCopyWith(
          _$CoinState_loading value, $Res Function(_$CoinState_loading) then) =
      __$$CoinState_loadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CoinState_loadingCopyWithImpl<$Res>
    extends _$CoinStateCopyWithImpl<$Res, _$CoinState_loading>
    implements _$$CoinState_loadingCopyWith<$Res> {
  __$$CoinState_loadingCopyWithImpl(
      _$CoinState_loading _value, $Res Function(_$CoinState_loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CoinState_loading implements CoinState_loading {
  const _$CoinState_loading();

  @override
  String toString() {
    return 'CoinState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$CoinState_loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(CoinFullModel coinModel) ready,
    required TResult Function(Object? error) error,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(CoinFullModel coinModel)? ready,
    TResult? Function(Object? error)? error,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(CoinFullModel coinModel)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CoinState_loading value) loading,
    required TResult Function(CoinState_Ready value) ready,
    required TResult Function(CoinState_Error value) error,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CoinState_loading value)? loading,
    TResult? Function(CoinState_Ready value)? ready,
    TResult? Function(CoinState_Error value)? error,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CoinState_loading value)? loading,
    TResult Function(CoinState_Ready value)? ready,
    TResult Function(CoinState_Error value)? error,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class CoinState_loading implements CoinState {
  const factory CoinState_loading() = _$CoinState_loading;
}

/// @nodoc
abstract class _$$CoinState_ReadyCopyWith<$Res> {
  factory _$$CoinState_ReadyCopyWith(
          _$CoinState_Ready value, $Res Function(_$CoinState_Ready) then) =
      __$$CoinState_ReadyCopyWithImpl<$Res>;
  @useResult
  $Res call({CoinFullModel coinModel});

  $CoinFullModelCopyWith<$Res> get coinModel;
}

/// @nodoc
class __$$CoinState_ReadyCopyWithImpl<$Res>
    extends _$CoinStateCopyWithImpl<$Res, _$CoinState_Ready>
    implements _$$CoinState_ReadyCopyWith<$Res> {
  __$$CoinState_ReadyCopyWithImpl(
      _$CoinState_Ready _value, $Res Function(_$CoinState_Ready) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? coinModel = null,
  }) {
    return _then(_$CoinState_Ready(
      coinModel: null == coinModel
          ? _value.coinModel
          : coinModel // ignore: cast_nullable_to_non_nullable
              as CoinFullModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $CoinFullModelCopyWith<$Res> get coinModel {
    return $CoinFullModelCopyWith<$Res>(_value.coinModel, (value) {
      return _then(_value.copyWith(coinModel: value));
    });
  }
}

/// @nodoc

class _$CoinState_Ready implements CoinState_Ready {
  const _$CoinState_Ready({required this.coinModel});

  @override
  final CoinFullModel coinModel;

  @override
  String toString() {
    return 'CoinState.ready(coinModel: $coinModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CoinState_Ready &&
            (identical(other.coinModel, coinModel) ||
                other.coinModel == coinModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, coinModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CoinState_ReadyCopyWith<_$CoinState_Ready> get copyWith =>
      __$$CoinState_ReadyCopyWithImpl<_$CoinState_Ready>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(CoinFullModel coinModel) ready,
    required TResult Function(Object? error) error,
  }) {
    return ready(coinModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(CoinFullModel coinModel)? ready,
    TResult? Function(Object? error)? error,
  }) {
    return ready?.call(coinModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(CoinFullModel coinModel)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(coinModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CoinState_loading value) loading,
    required TResult Function(CoinState_Ready value) ready,
    required TResult Function(CoinState_Error value) error,
  }) {
    return ready(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CoinState_loading value)? loading,
    TResult? Function(CoinState_Ready value)? ready,
    TResult? Function(CoinState_Error value)? error,
  }) {
    return ready?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CoinState_loading value)? loading,
    TResult Function(CoinState_Ready value)? ready,
    TResult Function(CoinState_Error value)? error,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(this);
    }
    return orElse();
  }
}

abstract class CoinState_Ready implements CoinState {
  const factory CoinState_Ready({required final CoinFullModel coinModel}) =
      _$CoinState_Ready;

  CoinFullModel get coinModel;
  @JsonKey(ignore: true)
  _$$CoinState_ReadyCopyWith<_$CoinState_Ready> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$CoinState_ErrorCopyWith<$Res> {
  factory _$$CoinState_ErrorCopyWith(
          _$CoinState_Error value, $Res Function(_$CoinState_Error) then) =
      __$$CoinState_ErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({Object? error});
}

/// @nodoc
class __$$CoinState_ErrorCopyWithImpl<$Res>
    extends _$CoinStateCopyWithImpl<$Res, _$CoinState_Error>
    implements _$$CoinState_ErrorCopyWith<$Res> {
  __$$CoinState_ErrorCopyWithImpl(
      _$CoinState_Error _value, $Res Function(_$CoinState_Error) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = freezed,
  }) {
    return _then(_$CoinState_Error(
      error: freezed == error ? _value.error : error,
    ));
  }
}

/// @nodoc

class _$CoinState_Error implements CoinState_Error {
  const _$CoinState_Error({this.error});

  @override
  final Object? error;

  @override
  String toString() {
    return 'CoinState.error(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CoinState_Error &&
            const DeepCollectionEquality().equals(other.error, error));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(error));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CoinState_ErrorCopyWith<_$CoinState_Error> get copyWith =>
      __$$CoinState_ErrorCopyWithImpl<_$CoinState_Error>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(CoinFullModel coinModel) ready,
    required TResult Function(Object? error) error,
  }) {
    return error(this.error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(CoinFullModel coinModel)? ready,
    TResult? Function(Object? error)? error,
  }) {
    return error?.call(this.error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(CoinFullModel coinModel)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this.error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CoinState_loading value) loading,
    required TResult Function(CoinState_Ready value) ready,
    required TResult Function(CoinState_Error value) error,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CoinState_loading value)? loading,
    TResult? Function(CoinState_Ready value)? ready,
    TResult? Function(CoinState_Error value)? error,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CoinState_loading value)? loading,
    TResult Function(CoinState_Ready value)? ready,
    TResult Function(CoinState_Error value)? error,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class CoinState_Error implements CoinState {
  const factory CoinState_Error({final Object? error}) = _$CoinState_Error;

  Object? get error;
  @JsonKey(ignore: true)
  _$$CoinState_ErrorCopyWith<_$CoinState_Error> get copyWith =>
      throw _privateConstructorUsedError;
}
