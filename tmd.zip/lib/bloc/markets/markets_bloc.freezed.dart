// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'markets_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$MarketsEvent {
  String get currency => throw _privateConstructorUsedError;
  String? get order => throw _privateConstructorUsedError;
  int? get pageNumber => throw _privateConstructorUsedError;
  int? get perPage => throw _privateConstructorUsedError;
  bool? get sparkline => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String currency, String? order, int? pageNumber,
            int? perPage, bool? sparkline)
        getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String currency, String? order, int? pageNumber,
            int? perPage, bool? sparkline)?
        getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String currency, String? order, int? pageNumber,
            int? perPage, bool? sparkline)?
        getMarketCoins,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MarketsEvent_OnGetMarketCoin value)
        getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(MarketsEvent_OnGetMarketCoin value)? getMarketCoins,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MarketsEvent_OnGetMarketCoin value)? getMarketCoins,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MarketsEventCopyWith<MarketsEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MarketsEventCopyWith<$Res> {
  factory $MarketsEventCopyWith(
          MarketsEvent value, $Res Function(MarketsEvent) then) =
      _$MarketsEventCopyWithImpl<$Res, MarketsEvent>;
  @useResult
  $Res call(
      {String currency,
      String? order,
      int? pageNumber,
      int? perPage,
      bool? sparkline});
}

/// @nodoc
class _$MarketsEventCopyWithImpl<$Res, $Val extends MarketsEvent>
    implements $MarketsEventCopyWith<$Res> {
  _$MarketsEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currency = null,
    Object? order = freezed,
    Object? pageNumber = freezed,
    Object? perPage = freezed,
    Object? sparkline = freezed,
  }) {
    return _then(_value.copyWith(
      currency: null == currency
          ? _value.currency
          : currency // ignore: cast_nullable_to_non_nullable
              as String,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as String?,
      pageNumber: freezed == pageNumber
          ? _value.pageNumber
          : pageNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      perPage: freezed == perPage
          ? _value.perPage
          : perPage // ignore: cast_nullable_to_non_nullable
              as int?,
      sparkline: freezed == sparkline
          ? _value.sparkline
          : sparkline // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MarketsEvent_OnGetMarketCoinCopyWith<$Res>
    implements $MarketsEventCopyWith<$Res> {
  factory _$$MarketsEvent_OnGetMarketCoinCopyWith(
          _$MarketsEvent_OnGetMarketCoin value,
          $Res Function(_$MarketsEvent_OnGetMarketCoin) then) =
      __$$MarketsEvent_OnGetMarketCoinCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String currency,
      String? order,
      int? pageNumber,
      int? perPage,
      bool? sparkline});
}

/// @nodoc
class __$$MarketsEvent_OnGetMarketCoinCopyWithImpl<$Res>
    extends _$MarketsEventCopyWithImpl<$Res, _$MarketsEvent_OnGetMarketCoin>
    implements _$$MarketsEvent_OnGetMarketCoinCopyWith<$Res> {
  __$$MarketsEvent_OnGetMarketCoinCopyWithImpl(
      _$MarketsEvent_OnGetMarketCoin _value,
      $Res Function(_$MarketsEvent_OnGetMarketCoin) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currency = null,
    Object? order = freezed,
    Object? pageNumber = freezed,
    Object? perPage = freezed,
    Object? sparkline = freezed,
  }) {
    return _then(_$MarketsEvent_OnGetMarketCoin(
      currency: null == currency
          ? _value.currency
          : currency // ignore: cast_nullable_to_non_nullable
              as String,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as String?,
      pageNumber: freezed == pageNumber
          ? _value.pageNumber
          : pageNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      perPage: freezed == perPage
          ? _value.perPage
          : perPage // ignore: cast_nullable_to_non_nullable
              as int?,
      sparkline: freezed == sparkline
          ? _value.sparkline
          : sparkline // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$MarketsEvent_OnGetMarketCoin implements MarketsEvent_OnGetMarketCoin {
  const _$MarketsEvent_OnGetMarketCoin(
      {required this.currency,
      this.order,
      this.pageNumber,
      this.perPage,
      this.sparkline});

  @override
  final String currency;
  @override
  final String? order;
  @override
  final int? pageNumber;
  @override
  final int? perPage;
  @override
  final bool? sparkline;

  @override
  String toString() {
    return 'MarketsEvent.getMarketCoins(currency: $currency, order: $order, pageNumber: $pageNumber, perPage: $perPage, sparkline: $sparkline)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MarketsEvent_OnGetMarketCoin &&
            (identical(other.currency, currency) ||
                other.currency == currency) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.pageNumber, pageNumber) ||
                other.pageNumber == pageNumber) &&
            (identical(other.perPage, perPage) || other.perPage == perPage) &&
            (identical(other.sparkline, sparkline) ||
                other.sparkline == sparkline));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, currency, order, pageNumber, perPage, sparkline);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MarketsEvent_OnGetMarketCoinCopyWith<_$MarketsEvent_OnGetMarketCoin>
      get copyWith => __$$MarketsEvent_OnGetMarketCoinCopyWithImpl<
          _$MarketsEvent_OnGetMarketCoin>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String currency, String? order, int? pageNumber,
            int? perPage, bool? sparkline)
        getMarketCoins,
  }) {
    return getMarketCoins(currency, order, pageNumber, perPage, sparkline);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String currency, String? order, int? pageNumber,
            int? perPage, bool? sparkline)?
        getMarketCoins,
  }) {
    return getMarketCoins?.call(
        currency, order, pageNumber, perPage, sparkline);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String currency, String? order, int? pageNumber,
            int? perPage, bool? sparkline)?
        getMarketCoins,
    required TResult orElse(),
  }) {
    if (getMarketCoins != null) {
      return getMarketCoins(currency, order, pageNumber, perPage, sparkline);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MarketsEvent_OnGetMarketCoin value)
        getMarketCoins,
  }) {
    return getMarketCoins(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(MarketsEvent_OnGetMarketCoin value)? getMarketCoins,
  }) {
    return getMarketCoins?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MarketsEvent_OnGetMarketCoin value)? getMarketCoins,
    required TResult orElse(),
  }) {
    if (getMarketCoins != null) {
      return getMarketCoins(this);
    }
    return orElse();
  }
}

abstract class MarketsEvent_OnGetMarketCoin implements MarketsEvent {
  const factory MarketsEvent_OnGetMarketCoin(
      {required final String currency,
      final String? order,
      final int? pageNumber,
      final int? perPage,
      final bool? sparkline}) = _$MarketsEvent_OnGetMarketCoin;

  @override
  String get currency;
  @override
  String? get order;
  @override
  int? get pageNumber;
  @override
  int? get perPage;
  @override
  bool? get sparkline;
  @override
  @JsonKey(ignore: true)
  _$$MarketsEvent_OnGetMarketCoinCopyWith<_$MarketsEvent_OnGetMarketCoin>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MarketsState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Iterable<MarketModel> markets) ready,
    required TResult Function(Object? error) error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Iterable<MarketModel> markets)? ready,
    TResult? Function(Object? error)? error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Iterable<MarketModel> markets)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MarketsState_loading value) loading,
    required TResult Function(MarketsState_Ready value) ready,
    required TResult Function(MarketsState_Error value) error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(MarketsState_loading value)? loading,
    TResult? Function(MarketsState_Ready value)? ready,
    TResult? Function(MarketsState_Error value)? error,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MarketsState_loading value)? loading,
    TResult Function(MarketsState_Ready value)? ready,
    TResult Function(MarketsState_Error value)? error,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MarketsStateCopyWith<$Res> {
  factory $MarketsStateCopyWith(
          MarketsState value, $Res Function(MarketsState) then) =
      _$MarketsStateCopyWithImpl<$Res, MarketsState>;
}

/// @nodoc
class _$MarketsStateCopyWithImpl<$Res, $Val extends MarketsState>
    implements $MarketsStateCopyWith<$Res> {
  _$MarketsStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$MarketsState_loadingCopyWith<$Res> {
  factory _$$MarketsState_loadingCopyWith(_$MarketsState_loading value,
          $Res Function(_$MarketsState_loading) then) =
      __$$MarketsState_loadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$MarketsState_loadingCopyWithImpl<$Res>
    extends _$MarketsStateCopyWithImpl<$Res, _$MarketsState_loading>
    implements _$$MarketsState_loadingCopyWith<$Res> {
  __$$MarketsState_loadingCopyWithImpl(_$MarketsState_loading _value,
      $Res Function(_$MarketsState_loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$MarketsState_loading implements MarketsState_loading {
  const _$MarketsState_loading();

  @override
  String toString() {
    return 'MarketsState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$MarketsState_loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Iterable<MarketModel> markets) ready,
    required TResult Function(Object? error) error,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Iterable<MarketModel> markets)? ready,
    TResult? Function(Object? error)? error,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Iterable<MarketModel> markets)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MarketsState_loading value) loading,
    required TResult Function(MarketsState_Ready value) ready,
    required TResult Function(MarketsState_Error value) error,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(MarketsState_loading value)? loading,
    TResult? Function(MarketsState_Ready value)? ready,
    TResult? Function(MarketsState_Error value)? error,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MarketsState_loading value)? loading,
    TResult Function(MarketsState_Ready value)? ready,
    TResult Function(MarketsState_Error value)? error,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class MarketsState_loading implements MarketsState {
  const factory MarketsState_loading() = _$MarketsState_loading;
}

/// @nodoc
abstract class _$$MarketsState_ReadyCopyWith<$Res> {
  factory _$$MarketsState_ReadyCopyWith(_$MarketsState_Ready value,
          $Res Function(_$MarketsState_Ready) then) =
      __$$MarketsState_ReadyCopyWithImpl<$Res>;
  @useResult
  $Res call({Iterable<MarketModel> markets});
}

/// @nodoc
class __$$MarketsState_ReadyCopyWithImpl<$Res>
    extends _$MarketsStateCopyWithImpl<$Res, _$MarketsState_Ready>
    implements _$$MarketsState_ReadyCopyWith<$Res> {
  __$$MarketsState_ReadyCopyWithImpl(
      _$MarketsState_Ready _value, $Res Function(_$MarketsState_Ready) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? markets = null,
  }) {
    return _then(_$MarketsState_Ready(
      markets: null == markets
          ? _value.markets
          : markets // ignore: cast_nullable_to_non_nullable
              as Iterable<MarketModel>,
    ));
  }
}

/// @nodoc

class _$MarketsState_Ready implements MarketsState_Ready {
  const _$MarketsState_Ready({required this.markets});

  @override
  final Iterable<MarketModel> markets;

  @override
  String toString() {
    return 'MarketsState.ready(markets: $markets)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MarketsState_Ready &&
            const DeepCollectionEquality().equals(other.markets, markets));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(markets));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MarketsState_ReadyCopyWith<_$MarketsState_Ready> get copyWith =>
      __$$MarketsState_ReadyCopyWithImpl<_$MarketsState_Ready>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Iterable<MarketModel> markets) ready,
    required TResult Function(Object? error) error,
  }) {
    return ready(markets);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Iterable<MarketModel> markets)? ready,
    TResult? Function(Object? error)? error,
  }) {
    return ready?.call(markets);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Iterable<MarketModel> markets)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(markets);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MarketsState_loading value) loading,
    required TResult Function(MarketsState_Ready value) ready,
    required TResult Function(MarketsState_Error value) error,
  }) {
    return ready(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(MarketsState_loading value)? loading,
    TResult? Function(MarketsState_Ready value)? ready,
    TResult? Function(MarketsState_Error value)? error,
  }) {
    return ready?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MarketsState_loading value)? loading,
    TResult Function(MarketsState_Ready value)? ready,
    TResult Function(MarketsState_Error value)? error,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(this);
    }
    return orElse();
  }
}

abstract class MarketsState_Ready implements MarketsState {
  const factory MarketsState_Ready(
      {required final Iterable<MarketModel> markets}) = _$MarketsState_Ready;

  Iterable<MarketModel> get markets;
  @JsonKey(ignore: true)
  _$$MarketsState_ReadyCopyWith<_$MarketsState_Ready> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MarketsState_ErrorCopyWith<$Res> {
  factory _$$MarketsState_ErrorCopyWith(_$MarketsState_Error value,
          $Res Function(_$MarketsState_Error) then) =
      __$$MarketsState_ErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({Object? error});
}

/// @nodoc
class __$$MarketsState_ErrorCopyWithImpl<$Res>
    extends _$MarketsStateCopyWithImpl<$Res, _$MarketsState_Error>
    implements _$$MarketsState_ErrorCopyWith<$Res> {
  __$$MarketsState_ErrorCopyWithImpl(
      _$MarketsState_Error _value, $Res Function(_$MarketsState_Error) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = freezed,
  }) {
    return _then(_$MarketsState_Error(
      error: freezed == error ? _value.error : error,
    ));
  }
}

/// @nodoc

class _$MarketsState_Error implements MarketsState_Error {
  const _$MarketsState_Error({this.error});

  @override
  final Object? error;

  @override
  String toString() {
    return 'MarketsState.error(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MarketsState_Error &&
            const DeepCollectionEquality().equals(other.error, error));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(error));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MarketsState_ErrorCopyWith<_$MarketsState_Error> get copyWith =>
      __$$MarketsState_ErrorCopyWithImpl<_$MarketsState_Error>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Iterable<MarketModel> markets) ready,
    required TResult Function(Object? error) error,
  }) {
    return error(this.error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Iterable<MarketModel> markets)? ready,
    TResult? Function(Object? error)? error,
  }) {
    return error?.call(this.error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Iterable<MarketModel> markets)? ready,
    TResult Function(Object? error)? error,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this.error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(MarketsState_loading value) loading,
    required TResult Function(MarketsState_Ready value) ready,
    required TResult Function(MarketsState_Error value) error,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(MarketsState_loading value)? loading,
    TResult? Function(MarketsState_Ready value)? ready,
    TResult? Function(MarketsState_Error value)? error,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(MarketsState_loading value)? loading,
    TResult Function(MarketsState_Ready value)? ready,
    TResult Function(MarketsState_Error value)? error,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class MarketsState_Error implements MarketsState {
  const factory MarketsState_Error({final Object? error}) =
      _$MarketsState_Error;

  Object? get error;
  @JsonKey(ignore: true)
  _$$MarketsState_ErrorCopyWith<_$MarketsState_Error> get copyWith =>
      throw _privateConstructorUsedError;
}
