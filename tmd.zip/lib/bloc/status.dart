enum BlocStatus {
  loading,
  ready,
  error,
}
