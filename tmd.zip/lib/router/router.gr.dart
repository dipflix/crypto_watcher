// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************
//
// ignore_for_file: type=lint

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i5;
import 'package:auto_route/empty_router_widgets.dart' as _i2;
import 'package:flutter/material.dart' as _i6;

import '../app.navigator.dart' as _i1;
import '../screens/detail/detail.screen.dart' as _i4;
import '../screens/screens.dart' as _i3;
import '../shared/models/market/market.model.dart' as _i7;

class AppRouter extends _i5.RootStackRouter {
  AppRouter([_i6.GlobalKey<_i6.NavigatorState>? navigatorKey])
      : super(navigatorKey);

  @override
  final Map<String, _i5.PageFactory> pagesMap = {
    AppNavigatorWrapper.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
        routeData: routeData,
        child: const _i1.AppNavigatorWrapper(),
      );
    },
    HomeRouter.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
        routeData: routeData,
        child: const _i2.EmptyRouterScreen(),
      );
    },
    MarketRouter.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
        routeData: routeData,
        child: const _i2.EmptyRouterScreen(),
      );
    },
    SettingsRouter.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
        routeData: routeData,
        child: const _i2.EmptyRouterScreen(),
      );
    },
    HomeRoute.name: (routeData) {
      final args =
          routeData.argsAs<HomeRouteArgs>(orElse: () => const HomeRouteArgs());
      return _i5.CustomPage<dynamic>(
        routeData: routeData,
        child: _i3.HomeScreen(key: args.key),
        transitionsBuilder: _i5.TransitionsBuilders.noTransition,
        opaque: true,
        barrierDismissible: false,
      );
    },
    CoinDetailRoute.name: (routeData) {
      final args = routeData.argsAs<CoinDetailRouteArgs>();
      return _i5.CustomPage<dynamic>(
        routeData: routeData,
        child: _i4.CoinDetailScreen(
          key: args.key,
          model: args.model,
        ),
        transitionsBuilder: _i5.TransitionsBuilders.noTransition,
        opaque: true,
        barrierDismissible: false,
      );
    },
    MarketRoute.name: (routeData) {
      return _i5.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i3.MarketScreen(),
        transitionsBuilder: _i5.TransitionsBuilders.noTransition,
        opaque: true,
        barrierDismissible: false,
      );
    },
    SettingRoute.name: (routeData) {
      return _i5.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i3.SettingScreen(),
        transitionsBuilder: _i5.TransitionsBuilders.noTransition,
        opaque: true,
        barrierDismissible: false,
      );
    },
  };

  @override
  List<_i5.RouteConfig> get routes => [
        _i5.RouteConfig(
          AppNavigatorWrapper.name,
          path: '/',
          children: [
            _i5.RouteConfig(
              HomeRouter.name,
              path: 'home',
              parent: AppNavigatorWrapper.name,
              children: [
                _i5.RouteConfig(
                  HomeRoute.name,
                  path: '',
                  parent: HomeRouter.name,
                ),
                _i5.RouteConfig(
                  CoinDetailRoute.name,
                  path: 'coinDetail',
                  parent: HomeRouter.name,
                ),
              ],
            ),
            _i5.RouteConfig(
              MarketRouter.name,
              path: 'market',
              parent: AppNavigatorWrapper.name,
              children: [
                _i5.RouteConfig(
                  MarketRoute.name,
                  path: '',
                  parent: MarketRouter.name,
                )
              ],
            ),
            _i5.RouteConfig(
              SettingsRouter.name,
              path: 'settings',
              parent: AppNavigatorWrapper.name,
              children: [
                _i5.RouteConfig(
                  SettingRoute.name,
                  path: '',
                  parent: SettingsRouter.name,
                )
              ],
            ),
          ],
        )
      ];
}

/// generated route for
/// [_i1.AppNavigatorWrapper]
class AppNavigatorWrapper extends _i5.PageRouteInfo<void> {
  const AppNavigatorWrapper({List<_i5.PageRouteInfo>? children})
      : super(
          AppNavigatorWrapper.name,
          path: '/',
          initialChildren: children,
        );

  static const String name = 'AppNavigatorWrapper';
}

/// generated route for
/// [_i2.EmptyRouterScreen]
class HomeRouter extends _i5.PageRouteInfo<void> {
  const HomeRouter({List<_i5.PageRouteInfo>? children})
      : super(
          HomeRouter.name,
          path: 'home',
          initialChildren: children,
        );

  static const String name = 'HomeRouter';
}

/// generated route for
/// [_i2.EmptyRouterScreen]
class MarketRouter extends _i5.PageRouteInfo<void> {
  const MarketRouter({List<_i5.PageRouteInfo>? children})
      : super(
          MarketRouter.name,
          path: 'market',
          initialChildren: children,
        );

  static const String name = 'MarketRouter';
}

/// generated route for
/// [_i2.EmptyRouterScreen]
class SettingsRouter extends _i5.PageRouteInfo<void> {
  const SettingsRouter({List<_i5.PageRouteInfo>? children})
      : super(
          SettingsRouter.name,
          path: 'settings',
          initialChildren: children,
        );

  static const String name = 'SettingsRouter';
}

/// generated route for
/// [_i3.HomeScreen]
class HomeRoute extends _i5.PageRouteInfo<HomeRouteArgs> {
  HomeRoute({_i6.Key? key})
      : super(
          HomeRoute.name,
          path: '',
          args: HomeRouteArgs(key: key),
        );

  static const String name = 'HomeRoute';
}

class HomeRouteArgs {
  const HomeRouteArgs({this.key});

  final _i6.Key? key;

  @override
  String toString() {
    return 'HomeRouteArgs{key: $key}';
  }
}

/// generated route for
/// [_i4.CoinDetailScreen]
class CoinDetailRoute extends _i5.PageRouteInfo<CoinDetailRouteArgs> {
  CoinDetailRoute({
    _i6.Key? key,
    required _i7.MarketModel model,
  }) : super(
          CoinDetailRoute.name,
          path: 'coinDetail',
          args: CoinDetailRouteArgs(
            key: key,
            model: model,
          ),
        );

  static const String name = 'CoinDetailRoute';
}

class CoinDetailRouteArgs {
  const CoinDetailRouteArgs({
    this.key,
    required this.model,
  });

  final _i6.Key? key;

  final _i7.MarketModel model;

  @override
  String toString() {
    return 'CoinDetailRouteArgs{key: $key, model: $model}';
  }
}

/// generated route for
/// [_i3.MarketScreen]
class MarketRoute extends _i5.PageRouteInfo<void> {
  const MarketRoute()
      : super(
          MarketRoute.name,
          path: '',
        );

  static const String name = 'MarketRoute';
}

/// generated route for
/// [_i3.SettingScreen]
class SettingRoute extends _i5.PageRouteInfo<void> {
  const SettingRoute()
      : super(
          SettingRoute.name,
          path: '',
        );

  static const String name = 'SettingRoute';
}
