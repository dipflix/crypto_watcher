import 'package:crypto_watcher/bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import 'package:crypto_watcher/uikit/uikit.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HomeScreen extends StatelessWidget {
  late final MarketsBloc marketsBloc;

  HomeScreen({Key? key}) : super(key: key) {
    marketsBloc = MarketsBloc();
    _getCoins();
  }

  void _getCoins() {
    marketsBloc.add(MarketsEvent.getMarketCoins(currency: "USD", perPage: 10));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MainAppBar(
        title: TextBody("markets".tr()),
      ),
      body: BlocProvider.value(
        value: marketsBloc,
        child: RefreshIndicator(
          onRefresh: () async {
            _getCoins();
          },
          child: SingleChildScrollView(
            physics: AlwaysScrollableScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: BlocBuilder<MarketsBloc, MarketsState>(
                builder: (context, state) {
                  return state.when(
                      loading: () => Center(child: CircularProgressIndicator()),
                      ready: (markets) {
                        return Column(
                          children: [
                            SizedBox(
                              height: 300,
                              child: Column(
                                children: [
                                  ElevatedButton(
                                    onPressed: () {},
                                    child: Icon(Icons.abc),
                                  ),
                                ],
                              ),
                            ),
                            buildColumnList(
                              length: markets.length,
                              buildWidget: (index) =>
                                  MarketView(model: markets.elementAt(index)),
                              buildSpace: Gap.horizontal.regular,
                            ),
                          ],
                        );
                      },
                      error: (error) => TextBody(error.toString()));
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
