// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'asset_platforms.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

AssetPlatformsModel _$AssetPlatformsModelFromJson(Map<String, dynamic> json) {
  return _AssetPlatformsModel.fromJson(json);
}

/// @nodoc
mixin _$AssetPlatformsModel {
  String get id => throw _privateConstructorUsedError;
  int get chainIdentifier => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get shortname => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AssetPlatformsModelCopyWith<AssetPlatformsModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AssetPlatformsModelCopyWith<$Res> {
  factory $AssetPlatformsModelCopyWith(
          AssetPlatformsModel value, $Res Function(AssetPlatformsModel) then) =
      _$AssetPlatformsModelCopyWithImpl<$Res, AssetPlatformsModel>;
  @useResult
  $Res call({String id, int chainIdentifier, String name, String shortname});
}

/// @nodoc
class _$AssetPlatformsModelCopyWithImpl<$Res, $Val extends AssetPlatformsModel>
    implements $AssetPlatformsModelCopyWith<$Res> {
  _$AssetPlatformsModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? chainIdentifier = null,
    Object? name = null,
    Object? shortname = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      chainIdentifier: null == chainIdentifier
          ? _value.chainIdentifier
          : chainIdentifier // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      shortname: null == shortname
          ? _value.shortname
          : shortname // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_AssetPlatformsModelCopyWith<$Res>
    implements $AssetPlatformsModelCopyWith<$Res> {
  factory _$$_AssetPlatformsModelCopyWith(_$_AssetPlatformsModel value,
          $Res Function(_$_AssetPlatformsModel) then) =
      __$$_AssetPlatformsModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String id, int chainIdentifier, String name, String shortname});
}

/// @nodoc
class __$$_AssetPlatformsModelCopyWithImpl<$Res>
    extends _$AssetPlatformsModelCopyWithImpl<$Res, _$_AssetPlatformsModel>
    implements _$$_AssetPlatformsModelCopyWith<$Res> {
  __$$_AssetPlatformsModelCopyWithImpl(_$_AssetPlatformsModel _value,
      $Res Function(_$_AssetPlatformsModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? chainIdentifier = null,
    Object? name = null,
    Object? shortname = null,
  }) {
    return _then(_$_AssetPlatformsModel(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      chainIdentifier: null == chainIdentifier
          ? _value.chainIdentifier
          : chainIdentifier // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      shortname: null == shortname
          ? _value.shortname
          : shortname // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_AssetPlatformsModel implements _AssetPlatformsModel {
  const _$_AssetPlatformsModel(
      {required this.id,
      required this.chainIdentifier,
      required this.name,
      required this.shortname});

  factory _$_AssetPlatformsModel.fromJson(Map<String, dynamic> json) =>
      _$$_AssetPlatformsModelFromJson(json);

  @override
  final String id;
  @override
  final int chainIdentifier;
  @override
  final String name;
  @override
  final String shortname;

  @override
  String toString() {
    return 'AssetPlatformsModel(id: $id, chainIdentifier: $chainIdentifier, name: $name, shortname: $shortname)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AssetPlatformsModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.chainIdentifier, chainIdentifier) ||
                other.chainIdentifier == chainIdentifier) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.shortname, shortname) ||
                other.shortname == shortname));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, chainIdentifier, name, shortname);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AssetPlatformsModelCopyWith<_$_AssetPlatformsModel> get copyWith =>
      __$$_AssetPlatformsModelCopyWithImpl<_$_AssetPlatformsModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AssetPlatformsModelToJson(
      this,
    );
  }
}

abstract class _AssetPlatformsModel implements AssetPlatformsModel {
  const factory _AssetPlatformsModel(
      {required final String id,
      required final int chainIdentifier,
      required final String name,
      required final String shortname}) = _$_AssetPlatformsModel;

  factory _AssetPlatformsModel.fromJson(Map<String, dynamic> json) =
      _$_AssetPlatformsModel.fromJson;

  @override
  String get id;
  @override
  int get chainIdentifier;
  @override
  String get name;
  @override
  String get shortname;
  @override
  @JsonKey(ignore: true)
  _$$_AssetPlatformsModelCopyWith<_$_AssetPlatformsModel> get copyWith =>
      throw _privateConstructorUsedError;
}
