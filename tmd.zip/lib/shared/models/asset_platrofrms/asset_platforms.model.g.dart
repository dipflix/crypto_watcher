// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'asset_platforms.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AssetPlatformsModel _$$_AssetPlatformsModelFromJson(Map json) =>
    _$_AssetPlatformsModel(
      id: json['id'] as String,
      chainIdentifier: json['chain_identifier'] as int,
      name: json['name'] as String,
      shortname: json['shortname'] as String,
    );

Map<String, dynamic> _$$_AssetPlatformsModelToJson(
        _$_AssetPlatformsModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'chain_identifier': instance.chainIdentifier,
      'name': instance.name,
      'shortname': instance.shortname,
    };
