// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'community_data.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

CoinFullModel _$CoinFullModelFromJson(Map<String, dynamic> json) {
  return _CoinFullModel.fromJson(json);
}

/// @nodoc
mixin _$CoinFullModel {
  String get id => throw _privateConstructorUsedError;
  String get symbol => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  int get blockTimeInMinutes => throw _privateConstructorUsedError;
  String get hashingAlgorithm => throw _privateConstructorUsedError;
  List<String> get categories => throw _privateConstructorUsedError;
  int? get publicNotice => throw _privateConstructorUsedError;
  LinksModel get links => throw _privateConstructorUsedError;
  ImageModel get image => throw _privateConstructorUsedError;
  String get countryOrigin => throw _privateConstructorUsedError;
  int get coingeckoRank => throw _privateConstructorUsedError;
  double get coingeckoScore => throw _privateConstructorUsedError;
  double get developerScore => throw _privateConstructorUsedError;
  double get communityScore => throw _privateConstructorUsedError;
  int get liquidityScore => throw _privateConstructorUsedError;
  int get publicInterestScore => throw _privateConstructorUsedError;
  DeveloperDataModel get developerData => throw _privateConstructorUsedError;
  DateTime get lastUpdated => throw _privateConstructorUsedError;
  List<TickerModel> get tickers => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CoinFullModelCopyWith<CoinFullModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CoinFullModelCopyWith<$Res> {
  factory $CoinFullModelCopyWith(
          CoinFullModel value, $Res Function(CoinFullModel) then) =
      _$CoinFullModelCopyWithImpl<$Res, CoinFullModel>;
  @useResult
  $Res call(
      {String id,
      String symbol,
      String name,
      int blockTimeInMinutes,
      String hashingAlgorithm,
      List<String> categories,
      int? publicNotice,
      LinksModel links,
      ImageModel image,
      String countryOrigin,
      int coingeckoRank,
      double coingeckoScore,
      double developerScore,
      double communityScore,
      int liquidityScore,
      int publicInterestScore,
      DeveloperDataModel developerData,
      DateTime lastUpdated,
      List<TickerModel> tickers});

  $LinksModelCopyWith<$Res> get links;
  $ImageModelCopyWith<$Res> get image;
  $DeveloperDataModelCopyWith<$Res> get developerData;
}

/// @nodoc
class _$CoinFullModelCopyWithImpl<$Res, $Val extends CoinFullModel>
    implements $CoinFullModelCopyWith<$Res> {
  _$CoinFullModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? symbol = null,
    Object? name = null,
    Object? blockTimeInMinutes = null,
    Object? hashingAlgorithm = null,
    Object? categories = null,
    Object? publicNotice = freezed,
    Object? links = null,
    Object? image = null,
    Object? countryOrigin = null,
    Object? coingeckoRank = null,
    Object? coingeckoScore = null,
    Object? developerScore = null,
    Object? communityScore = null,
    Object? liquidityScore = null,
    Object? publicInterestScore = null,
    Object? developerData = null,
    Object? lastUpdated = null,
    Object? tickers = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      symbol: null == symbol
          ? _value.symbol
          : symbol // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      blockTimeInMinutes: null == blockTimeInMinutes
          ? _value.blockTimeInMinutes
          : blockTimeInMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      hashingAlgorithm: null == hashingAlgorithm
          ? _value.hashingAlgorithm
          : hashingAlgorithm // ignore: cast_nullable_to_non_nullable
              as String,
      categories: null == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as List<String>,
      publicNotice: freezed == publicNotice
          ? _value.publicNotice
          : publicNotice // ignore: cast_nullable_to_non_nullable
              as int?,
      links: null == links
          ? _value.links
          : links // ignore: cast_nullable_to_non_nullable
              as LinksModel,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as ImageModel,
      countryOrigin: null == countryOrigin
          ? _value.countryOrigin
          : countryOrigin // ignore: cast_nullable_to_non_nullable
              as String,
      coingeckoRank: null == coingeckoRank
          ? _value.coingeckoRank
          : coingeckoRank // ignore: cast_nullable_to_non_nullable
              as int,
      coingeckoScore: null == coingeckoScore
          ? _value.coingeckoScore
          : coingeckoScore // ignore: cast_nullable_to_non_nullable
              as double,
      developerScore: null == developerScore
          ? _value.developerScore
          : developerScore // ignore: cast_nullable_to_non_nullable
              as double,
      communityScore: null == communityScore
          ? _value.communityScore
          : communityScore // ignore: cast_nullable_to_non_nullable
              as double,
      liquidityScore: null == liquidityScore
          ? _value.liquidityScore
          : liquidityScore // ignore: cast_nullable_to_non_nullable
              as int,
      publicInterestScore: null == publicInterestScore
          ? _value.publicInterestScore
          : publicInterestScore // ignore: cast_nullable_to_non_nullable
              as int,
      developerData: null == developerData
          ? _value.developerData
          : developerData // ignore: cast_nullable_to_non_nullable
              as DeveloperDataModel,
      lastUpdated: null == lastUpdated
          ? _value.lastUpdated
          : lastUpdated // ignore: cast_nullable_to_non_nullable
              as DateTime,
      tickers: null == tickers
          ? _value.tickers
          : tickers // ignore: cast_nullable_to_non_nullable
              as List<TickerModel>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $LinksModelCopyWith<$Res> get links {
    return $LinksModelCopyWith<$Res>(_value.links, (value) {
      return _then(_value.copyWith(links: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $ImageModelCopyWith<$Res> get image {
    return $ImageModelCopyWith<$Res>(_value.image, (value) {
      return _then(_value.copyWith(image: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DeveloperDataModelCopyWith<$Res> get developerData {
    return $DeveloperDataModelCopyWith<$Res>(_value.developerData, (value) {
      return _then(_value.copyWith(developerData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_CoinFullModelCopyWith<$Res>
    implements $CoinFullModelCopyWith<$Res> {
  factory _$$_CoinFullModelCopyWith(
          _$_CoinFullModel value, $Res Function(_$_CoinFullModel) then) =
      __$$_CoinFullModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String symbol,
      String name,
      int blockTimeInMinutes,
      String hashingAlgorithm,
      List<String> categories,
      int? publicNotice,
      LinksModel links,
      ImageModel image,
      String countryOrigin,
      int coingeckoRank,
      double coingeckoScore,
      double developerScore,
      double communityScore,
      int liquidityScore,
      int publicInterestScore,
      DeveloperDataModel developerData,
      DateTime lastUpdated,
      List<TickerModel> tickers});

  @override
  $LinksModelCopyWith<$Res> get links;
  @override
  $ImageModelCopyWith<$Res> get image;
  @override
  $DeveloperDataModelCopyWith<$Res> get developerData;
}

/// @nodoc
class __$$_CoinFullModelCopyWithImpl<$Res>
    extends _$CoinFullModelCopyWithImpl<$Res, _$_CoinFullModel>
    implements _$$_CoinFullModelCopyWith<$Res> {
  __$$_CoinFullModelCopyWithImpl(
      _$_CoinFullModel _value, $Res Function(_$_CoinFullModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? symbol = null,
    Object? name = null,
    Object? blockTimeInMinutes = null,
    Object? hashingAlgorithm = null,
    Object? categories = null,
    Object? publicNotice = freezed,
    Object? links = null,
    Object? image = null,
    Object? countryOrigin = null,
    Object? coingeckoRank = null,
    Object? coingeckoScore = null,
    Object? developerScore = null,
    Object? communityScore = null,
    Object? liquidityScore = null,
    Object? publicInterestScore = null,
    Object? developerData = null,
    Object? lastUpdated = null,
    Object? tickers = null,
  }) {
    return _then(_$_CoinFullModel(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      symbol: null == symbol
          ? _value.symbol
          : symbol // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      blockTimeInMinutes: null == blockTimeInMinutes
          ? _value.blockTimeInMinutes
          : blockTimeInMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      hashingAlgorithm: null == hashingAlgorithm
          ? _value.hashingAlgorithm
          : hashingAlgorithm // ignore: cast_nullable_to_non_nullable
              as String,
      categories: null == categories
          ? _value._categories
          : categories // ignore: cast_nullable_to_non_nullable
              as List<String>,
      publicNotice: freezed == publicNotice
          ? _value.publicNotice
          : publicNotice // ignore: cast_nullable_to_non_nullable
              as int?,
      links: null == links
          ? _value.links
          : links // ignore: cast_nullable_to_non_nullable
              as LinksModel,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as ImageModel,
      countryOrigin: null == countryOrigin
          ? _value.countryOrigin
          : countryOrigin // ignore: cast_nullable_to_non_nullable
              as String,
      coingeckoRank: null == coingeckoRank
          ? _value.coingeckoRank
          : coingeckoRank // ignore: cast_nullable_to_non_nullable
              as int,
      coingeckoScore: null == coingeckoScore
          ? _value.coingeckoScore
          : coingeckoScore // ignore: cast_nullable_to_non_nullable
              as double,
      developerScore: null == developerScore
          ? _value.developerScore
          : developerScore // ignore: cast_nullable_to_non_nullable
              as double,
      communityScore: null == communityScore
          ? _value.communityScore
          : communityScore // ignore: cast_nullable_to_non_nullable
              as double,
      liquidityScore: null == liquidityScore
          ? _value.liquidityScore
          : liquidityScore // ignore: cast_nullable_to_non_nullable
              as int,
      publicInterestScore: null == publicInterestScore
          ? _value.publicInterestScore
          : publicInterestScore // ignore: cast_nullable_to_non_nullable
              as int,
      developerData: null == developerData
          ? _value.developerData
          : developerData // ignore: cast_nullable_to_non_nullable
              as DeveloperDataModel,
      lastUpdated: null == lastUpdated
          ? _value.lastUpdated
          : lastUpdated // ignore: cast_nullable_to_non_nullable
              as DateTime,
      tickers: null == tickers
          ? _value._tickers
          : tickers // ignore: cast_nullable_to_non_nullable
              as List<TickerModel>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_CoinFullModel implements _CoinFullModel {
  const _$_CoinFullModel(
      {required this.id,
      required this.symbol,
      required this.name,
      required this.blockTimeInMinutes,
      required this.hashingAlgorithm,
      required final List<String> categories,
      this.publicNotice,
      required this.links,
      required this.image,
      required this.countryOrigin,
      required this.coingeckoRank,
      required this.coingeckoScore,
      required this.developerScore,
      required this.communityScore,
      required this.liquidityScore,
      required this.publicInterestScore,
      required this.developerData,
      required this.lastUpdated,
      required final List<TickerModel> tickers})
      : _categories = categories,
        _tickers = tickers;

  factory _$_CoinFullModel.fromJson(Map<String, dynamic> json) =>
      _$$_CoinFullModelFromJson(json);

  @override
  final String id;
  @override
  final String symbol;
  @override
  final String name;
  @override
  final int blockTimeInMinutes;
  @override
  final String hashingAlgorithm;
  final List<String> _categories;
  @override
  List<String> get categories {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_categories);
  }

  @override
  final int? publicNotice;
  @override
  final LinksModel links;
  @override
  final ImageModel image;
  @override
  final String countryOrigin;
  @override
  final int coingeckoRank;
  @override
  final double coingeckoScore;
  @override
  final double developerScore;
  @override
  final double communityScore;
  @override
  final int liquidityScore;
  @override
  final int publicInterestScore;
  @override
  final DeveloperDataModel developerData;
  @override
  final DateTime lastUpdated;
  final List<TickerModel> _tickers;
  @override
  List<TickerModel> get tickers {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_tickers);
  }

  @override
  String toString() {
    return 'CoinFullModel(id: $id, symbol: $symbol, name: $name, blockTimeInMinutes: $blockTimeInMinutes, hashingAlgorithm: $hashingAlgorithm, categories: $categories, publicNotice: $publicNotice, links: $links, image: $image, countryOrigin: $countryOrigin, coingeckoRank: $coingeckoRank, coingeckoScore: $coingeckoScore, developerScore: $developerScore, communityScore: $communityScore, liquidityScore: $liquidityScore, publicInterestScore: $publicInterestScore, developerData: $developerData, lastUpdated: $lastUpdated, tickers: $tickers)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CoinFullModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.symbol, symbol) || other.symbol == symbol) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.blockTimeInMinutes, blockTimeInMinutes) ||
                other.blockTimeInMinutes == blockTimeInMinutes) &&
            (identical(other.hashingAlgorithm, hashingAlgorithm) ||
                other.hashingAlgorithm == hashingAlgorithm) &&
            const DeepCollectionEquality()
                .equals(other._categories, _categories) &&
            (identical(other.publicNotice, publicNotice) ||
                other.publicNotice == publicNotice) &&
            (identical(other.links, links) || other.links == links) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.countryOrigin, countryOrigin) ||
                other.countryOrigin == countryOrigin) &&
            (identical(other.coingeckoRank, coingeckoRank) ||
                other.coingeckoRank == coingeckoRank) &&
            (identical(other.coingeckoScore, coingeckoScore) ||
                other.coingeckoScore == coingeckoScore) &&
            (identical(other.developerScore, developerScore) ||
                other.developerScore == developerScore) &&
            (identical(other.communityScore, communityScore) ||
                other.communityScore == communityScore) &&
            (identical(other.liquidityScore, liquidityScore) ||
                other.liquidityScore == liquidityScore) &&
            (identical(other.publicInterestScore, publicInterestScore) ||
                other.publicInterestScore == publicInterestScore) &&
            (identical(other.developerData, developerData) ||
                other.developerData == developerData) &&
            (identical(other.lastUpdated, lastUpdated) ||
                other.lastUpdated == lastUpdated) &&
            const DeepCollectionEquality().equals(other._tickers, _tickers));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        symbol,
        name,
        blockTimeInMinutes,
        hashingAlgorithm,
        const DeepCollectionEquality().hash(_categories),
        publicNotice,
        links,
        image,
        countryOrigin,
        coingeckoRank,
        coingeckoScore,
        developerScore,
        communityScore,
        liquidityScore,
        publicInterestScore,
        developerData,
        lastUpdated,
        const DeepCollectionEquality().hash(_tickers)
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CoinFullModelCopyWith<_$_CoinFullModel> get copyWith =>
      __$$_CoinFullModelCopyWithImpl<_$_CoinFullModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_CoinFullModelToJson(
      this,
    );
  }
}

abstract class _CoinFullModel implements CoinFullModel {
  const factory _CoinFullModel(
      {required final String id,
      required final String symbol,
      required final String name,
      required final int blockTimeInMinutes,
      required final String hashingAlgorithm,
      required final List<String> categories,
      final int? publicNotice,
      required final LinksModel links,
      required final ImageModel image,
      required final String countryOrigin,
      required final int coingeckoRank,
      required final double coingeckoScore,
      required final double developerScore,
      required final double communityScore,
      required final int liquidityScore,
      required final int publicInterestScore,
      required final DeveloperDataModel developerData,
      required final DateTime lastUpdated,
      required final List<TickerModel> tickers}) = _$_CoinFullModel;

  factory _CoinFullModel.fromJson(Map<String, dynamic> json) =
      _$_CoinFullModel.fromJson;

  @override
  String get id;
  @override
  String get symbol;
  @override
  String get name;
  @override
  int get blockTimeInMinutes;
  @override
  String get hashingAlgorithm;
  @override
  List<String> get categories;
  @override
  int? get publicNotice;
  @override
  LinksModel get links;
  @override
  ImageModel get image;
  @override
  String get countryOrigin;
  @override
  int get coingeckoRank;
  @override
  double get coingeckoScore;
  @override
  double get developerScore;
  @override
  double get communityScore;
  @override
  int get liquidityScore;
  @override
  int get publicInterestScore;
  @override
  DeveloperDataModel get developerData;
  @override
  DateTime get lastUpdated;
  @override
  List<TickerModel> get tickers;
  @override
  @JsonKey(ignore: true)
  _$$_CoinFullModelCopyWith<_$_CoinFullModel> get copyWith =>
      throw _privateConstructorUsedError;
}
