// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'community_data.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CoinFullModel _$$_CoinFullModelFromJson(Map json) => _$_CoinFullModel(
      id: json['id'] as String,
      symbol: json['symbol'] as String,
      name: json['name'] as String,
      blockTimeInMinutes: json['block_time_in_minutes'] as int,
      hashingAlgorithm: json['hashing_algorithm'] as String,
      categories: (json['categories'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      publicNotice: json['public_notice'] as int?,
      links:
          LinksModel.fromJson(Map<String, dynamic>.from(json['links'] as Map)),
      image:
          ImageModel.fromJson(Map<String, dynamic>.from(json['image'] as Map)),
      countryOrigin: json['country_origin'] as String,
      coingeckoRank: json['coingecko_rank'] as int,
      coingeckoScore: (json['coingecko_score'] as num).toDouble(),
      developerScore: (json['developer_score'] as num).toDouble(),
      communityScore: (json['community_score'] as num).toDouble(),
      liquidityScore: json['liquidity_score'] as int,
      publicInterestScore: json['public_interest_score'] as int,
      developerData: DeveloperDataModel.fromJson(
          Map<String, dynamic>.from(json['developer_data'] as Map)),
      lastUpdated: DateTime.parse(json['last_updated'] as String),
      tickers: (json['tickers'] as List<dynamic>)
          .map((e) => TickerModel.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
    );

Map<String, dynamic> _$$_CoinFullModelToJson(_$_CoinFullModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'symbol': instance.symbol,
      'name': instance.name,
      'block_time_in_minutes': instance.blockTimeInMinutes,
      'hashing_algorithm': instance.hashingAlgorithm,
      'categories': instance.categories,
      'public_notice': instance.publicNotice,
      'links': instance.links,
      'image': instance.image,
      'country_origin': instance.countryOrigin,
      'coingecko_rank': instance.coingeckoRank,
      'coingecko_score': instance.coingeckoScore,
      'developer_score': instance.developerScore,
      'community_score': instance.communityScore,
      'liquidity_score': instance.liquidityScore,
      'public_interest_score': instance.publicInterestScore,
      'developer_data': instance.developerData,
      'last_updated': instance.lastUpdated.toIso8601String(),
      'tickers': instance.tickers,
    };
