// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'developer_data.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

DeveloperDataModel _$DeveloperDataModelFromJson(Map<String, dynamic> json) {
  return _DeveloperDataModel.fromJson(json);
}

/// @nodoc
mixin _$DeveloperDataModel {
  int get forks => throw _privateConstructorUsedError;
  int get stars => throw _privateConstructorUsedError;
  int get subscribers => throw _privateConstructorUsedError;
  int get totalIssues => throw _privateConstructorUsedError;
  int get closedIssues => throw _privateConstructorUsedError;
  int get pullRequestsMerged => throw _privateConstructorUsedError;
  int get pullRequestContributors => throw _privateConstructorUsedError;
  int get commitCount4Weeks => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DeveloperDataModelCopyWith<DeveloperDataModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeveloperDataModelCopyWith<$Res> {
  factory $DeveloperDataModelCopyWith(
          DeveloperDataModel value, $Res Function(DeveloperDataModel) then) =
      _$DeveloperDataModelCopyWithImpl<$Res, DeveloperDataModel>;
  @useResult
  $Res call(
      {int forks,
      int stars,
      int subscribers,
      int totalIssues,
      int closedIssues,
      int pullRequestsMerged,
      int pullRequestContributors,
      int commitCount4Weeks});
}

/// @nodoc
class _$DeveloperDataModelCopyWithImpl<$Res, $Val extends DeveloperDataModel>
    implements $DeveloperDataModelCopyWith<$Res> {
  _$DeveloperDataModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? forks = null,
    Object? stars = null,
    Object? subscribers = null,
    Object? totalIssues = null,
    Object? closedIssues = null,
    Object? pullRequestsMerged = null,
    Object? pullRequestContributors = null,
    Object? commitCount4Weeks = null,
  }) {
    return _then(_value.copyWith(
      forks: null == forks
          ? _value.forks
          : forks // ignore: cast_nullable_to_non_nullable
              as int,
      stars: null == stars
          ? _value.stars
          : stars // ignore: cast_nullable_to_non_nullable
              as int,
      subscribers: null == subscribers
          ? _value.subscribers
          : subscribers // ignore: cast_nullable_to_non_nullable
              as int,
      totalIssues: null == totalIssues
          ? _value.totalIssues
          : totalIssues // ignore: cast_nullable_to_non_nullable
              as int,
      closedIssues: null == closedIssues
          ? _value.closedIssues
          : closedIssues // ignore: cast_nullable_to_non_nullable
              as int,
      pullRequestsMerged: null == pullRequestsMerged
          ? _value.pullRequestsMerged
          : pullRequestsMerged // ignore: cast_nullable_to_non_nullable
              as int,
      pullRequestContributors: null == pullRequestContributors
          ? _value.pullRequestContributors
          : pullRequestContributors // ignore: cast_nullable_to_non_nullable
              as int,
      commitCount4Weeks: null == commitCount4Weeks
          ? _value.commitCount4Weeks
          : commitCount4Weeks // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_DeveloperDataModelCopyWith<$Res>
    implements $DeveloperDataModelCopyWith<$Res> {
  factory _$$_DeveloperDataModelCopyWith(_$_DeveloperDataModel value,
          $Res Function(_$_DeveloperDataModel) then) =
      __$$_DeveloperDataModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int forks,
      int stars,
      int subscribers,
      int totalIssues,
      int closedIssues,
      int pullRequestsMerged,
      int pullRequestContributors,
      int commitCount4Weeks});
}

/// @nodoc
class __$$_DeveloperDataModelCopyWithImpl<$Res>
    extends _$DeveloperDataModelCopyWithImpl<$Res, _$_DeveloperDataModel>
    implements _$$_DeveloperDataModelCopyWith<$Res> {
  __$$_DeveloperDataModelCopyWithImpl(
      _$_DeveloperDataModel _value, $Res Function(_$_DeveloperDataModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? forks = null,
    Object? stars = null,
    Object? subscribers = null,
    Object? totalIssues = null,
    Object? closedIssues = null,
    Object? pullRequestsMerged = null,
    Object? pullRequestContributors = null,
    Object? commitCount4Weeks = null,
  }) {
    return _then(_$_DeveloperDataModel(
      forks: null == forks
          ? _value.forks
          : forks // ignore: cast_nullable_to_non_nullable
              as int,
      stars: null == stars
          ? _value.stars
          : stars // ignore: cast_nullable_to_non_nullable
              as int,
      subscribers: null == subscribers
          ? _value.subscribers
          : subscribers // ignore: cast_nullable_to_non_nullable
              as int,
      totalIssues: null == totalIssues
          ? _value.totalIssues
          : totalIssues // ignore: cast_nullable_to_non_nullable
              as int,
      closedIssues: null == closedIssues
          ? _value.closedIssues
          : closedIssues // ignore: cast_nullable_to_non_nullable
              as int,
      pullRequestsMerged: null == pullRequestsMerged
          ? _value.pullRequestsMerged
          : pullRequestsMerged // ignore: cast_nullable_to_non_nullable
              as int,
      pullRequestContributors: null == pullRequestContributors
          ? _value.pullRequestContributors
          : pullRequestContributors // ignore: cast_nullable_to_non_nullable
              as int,
      commitCount4Weeks: null == commitCount4Weeks
          ? _value.commitCount4Weeks
          : commitCount4Weeks // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_DeveloperDataModel implements _DeveloperDataModel {
  const _$_DeveloperDataModel(
      {required this.forks,
      required this.stars,
      required this.subscribers,
      required this.totalIssues,
      required this.closedIssues,
      required this.pullRequestsMerged,
      required this.pullRequestContributors,
      required this.commitCount4Weeks});

  factory _$_DeveloperDataModel.fromJson(Map<String, dynamic> json) =>
      _$$_DeveloperDataModelFromJson(json);

  @override
  final int forks;
  @override
  final int stars;
  @override
  final int subscribers;
  @override
  final int totalIssues;
  @override
  final int closedIssues;
  @override
  final int pullRequestsMerged;
  @override
  final int pullRequestContributors;
  @override
  final int commitCount4Weeks;

  @override
  String toString() {
    return 'DeveloperDataModel(forks: $forks, stars: $stars, subscribers: $subscribers, totalIssues: $totalIssues, closedIssues: $closedIssues, pullRequestsMerged: $pullRequestsMerged, pullRequestContributors: $pullRequestContributors, commitCount4Weeks: $commitCount4Weeks)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DeveloperDataModel &&
            (identical(other.forks, forks) || other.forks == forks) &&
            (identical(other.stars, stars) || other.stars == stars) &&
            (identical(other.subscribers, subscribers) ||
                other.subscribers == subscribers) &&
            (identical(other.totalIssues, totalIssues) ||
                other.totalIssues == totalIssues) &&
            (identical(other.closedIssues, closedIssues) ||
                other.closedIssues == closedIssues) &&
            (identical(other.pullRequestsMerged, pullRequestsMerged) ||
                other.pullRequestsMerged == pullRequestsMerged) &&
            (identical(
                    other.pullRequestContributors, pullRequestContributors) ||
                other.pullRequestContributors == pullRequestContributors) &&
            (identical(other.commitCount4Weeks, commitCount4Weeks) ||
                other.commitCount4Weeks == commitCount4Weeks));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      forks,
      stars,
      subscribers,
      totalIssues,
      closedIssues,
      pullRequestsMerged,
      pullRequestContributors,
      commitCount4Weeks);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DeveloperDataModelCopyWith<_$_DeveloperDataModel> get copyWith =>
      __$$_DeveloperDataModelCopyWithImpl<_$_DeveloperDataModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_DeveloperDataModelToJson(
      this,
    );
  }
}

abstract class _DeveloperDataModel implements DeveloperDataModel {
  const factory _DeveloperDataModel(
      {required final int forks,
      required final int stars,
      required final int subscribers,
      required final int totalIssues,
      required final int closedIssues,
      required final int pullRequestsMerged,
      required final int pullRequestContributors,
      required final int commitCount4Weeks}) = _$_DeveloperDataModel;

  factory _DeveloperDataModel.fromJson(Map<String, dynamic> json) =
      _$_DeveloperDataModel.fromJson;

  @override
  int get forks;
  @override
  int get stars;
  @override
  int get subscribers;
  @override
  int get totalIssues;
  @override
  int get closedIssues;
  @override
  int get pullRequestsMerged;
  @override
  int get pullRequestContributors;
  @override
  int get commitCount4Weeks;
  @override
  @JsonKey(ignore: true)
  _$$_DeveloperDataModelCopyWith<_$_DeveloperDataModel> get copyWith =>
      throw _privateConstructorUsedError;
}
