// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'developer_data.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_DeveloperDataModel _$$_DeveloperDataModelFromJson(Map json) =>
    _$_DeveloperDataModel(
      forks: json['forks'] as int,
      stars: json['stars'] as int,
      subscribers: json['subscribers'] as int,
      totalIssues: json['total_issues'] as int,
      closedIssues: json['closed_issues'] as int,
      pullRequestsMerged: json['pull_requests_merged'] as int,
      pullRequestContributors: json['pull_request_contributors'] as int,
      commitCount4Weeks: json['commit_count4_weeks'] as int,
    );

Map<String, dynamic> _$$_DeveloperDataModelToJson(
        _$_DeveloperDataModel instance) =>
    <String, dynamic>{
      'forks': instance.forks,
      'stars': instance.stars,
      'subscribers': instance.subscribers,
      'total_issues': instance.totalIssues,
      'closed_issues': instance.closedIssues,
      'pull_requests_merged': instance.pullRequestsMerged,
      'pull_request_contributors': instance.pullRequestContributors,
      'commit_count4_weeks': instance.commitCount4Weeks,
    };
