// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'exchange.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ExchangeModel _$ExchangeModelFromJson(Map<String, dynamic> json) {
  return _ExchangeModel.fromJson(json);
}

/// @nodoc
mixin _$ExchangeModel {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  int get yearEstablished => throw _privateConstructorUsedError;
  String get country => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get url => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  bool get hasTradingIncentive => throw _privateConstructorUsedError;
  int get trustScore => throw _privateConstructorUsedError;
  int get trustScoreRank => throw _privateConstructorUsedError;
  double get tradeVolume24HBtc => throw _privateConstructorUsedError;
  double get tradeVolume24HBtcNormalized => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ExchangeModelCopyWith<ExchangeModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ExchangeModelCopyWith<$Res> {
  factory $ExchangeModelCopyWith(
          ExchangeModel value, $Res Function(ExchangeModel) then) =
      _$ExchangeModelCopyWithImpl<$Res, ExchangeModel>;
  @useResult
  $Res call(
      {String id,
      String name,
      int yearEstablished,
      String country,
      String description,
      String url,
      String image,
      bool hasTradingIncentive,
      int trustScore,
      int trustScoreRank,
      double tradeVolume24HBtc,
      double tradeVolume24HBtcNormalized});
}

/// @nodoc
class _$ExchangeModelCopyWithImpl<$Res, $Val extends ExchangeModel>
    implements $ExchangeModelCopyWith<$Res> {
  _$ExchangeModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? yearEstablished = null,
    Object? country = null,
    Object? description = null,
    Object? url = null,
    Object? image = null,
    Object? hasTradingIncentive = null,
    Object? trustScore = null,
    Object? trustScoreRank = null,
    Object? tradeVolume24HBtc = null,
    Object? tradeVolume24HBtcNormalized = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      yearEstablished: null == yearEstablished
          ? _value.yearEstablished
          : yearEstablished // ignore: cast_nullable_to_non_nullable
              as int,
      country: null == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      url: null == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      hasTradingIncentive: null == hasTradingIncentive
          ? _value.hasTradingIncentive
          : hasTradingIncentive // ignore: cast_nullable_to_non_nullable
              as bool,
      trustScore: null == trustScore
          ? _value.trustScore
          : trustScore // ignore: cast_nullable_to_non_nullable
              as int,
      trustScoreRank: null == trustScoreRank
          ? _value.trustScoreRank
          : trustScoreRank // ignore: cast_nullable_to_non_nullable
              as int,
      tradeVolume24HBtc: null == tradeVolume24HBtc
          ? _value.tradeVolume24HBtc
          : tradeVolume24HBtc // ignore: cast_nullable_to_non_nullable
              as double,
      tradeVolume24HBtcNormalized: null == tradeVolume24HBtcNormalized
          ? _value.tradeVolume24HBtcNormalized
          : tradeVolume24HBtcNormalized // ignore: cast_nullable_to_non_nullable
              as double,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ExchangeModelCopyWith<$Res>
    implements $ExchangeModelCopyWith<$Res> {
  factory _$$_ExchangeModelCopyWith(
          _$_ExchangeModel value, $Res Function(_$_ExchangeModel) then) =
      __$$_ExchangeModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      int yearEstablished,
      String country,
      String description,
      String url,
      String image,
      bool hasTradingIncentive,
      int trustScore,
      int trustScoreRank,
      double tradeVolume24HBtc,
      double tradeVolume24HBtcNormalized});
}

/// @nodoc
class __$$_ExchangeModelCopyWithImpl<$Res>
    extends _$ExchangeModelCopyWithImpl<$Res, _$_ExchangeModel>
    implements _$$_ExchangeModelCopyWith<$Res> {
  __$$_ExchangeModelCopyWithImpl(
      _$_ExchangeModel _value, $Res Function(_$_ExchangeModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? yearEstablished = null,
    Object? country = null,
    Object? description = null,
    Object? url = null,
    Object? image = null,
    Object? hasTradingIncentive = null,
    Object? trustScore = null,
    Object? trustScoreRank = null,
    Object? tradeVolume24HBtc = null,
    Object? tradeVolume24HBtcNormalized = null,
  }) {
    return _then(_$_ExchangeModel(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      yearEstablished: null == yearEstablished
          ? _value.yearEstablished
          : yearEstablished // ignore: cast_nullable_to_non_nullable
              as int,
      country: null == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      url: null == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      hasTradingIncentive: null == hasTradingIncentive
          ? _value.hasTradingIncentive
          : hasTradingIncentive // ignore: cast_nullable_to_non_nullable
              as bool,
      trustScore: null == trustScore
          ? _value.trustScore
          : trustScore // ignore: cast_nullable_to_non_nullable
              as int,
      trustScoreRank: null == trustScoreRank
          ? _value.trustScoreRank
          : trustScoreRank // ignore: cast_nullable_to_non_nullable
              as int,
      tradeVolume24HBtc: null == tradeVolume24HBtc
          ? _value.tradeVolume24HBtc
          : tradeVolume24HBtc // ignore: cast_nullable_to_non_nullable
              as double,
      tradeVolume24HBtcNormalized: null == tradeVolume24HBtcNormalized
          ? _value.tradeVolume24HBtcNormalized
          : tradeVolume24HBtcNormalized // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ExchangeModel implements _ExchangeModel {
  const _$_ExchangeModel(
      {required this.id,
      required this.name,
      required this.yearEstablished,
      required this.country,
      required this.description,
      required this.url,
      required this.image,
      required this.hasTradingIncentive,
      required this.trustScore,
      required this.trustScoreRank,
      required this.tradeVolume24HBtc,
      required this.tradeVolume24HBtcNormalized});

  factory _$_ExchangeModel.fromJson(Map<String, dynamic> json) =>
      _$$_ExchangeModelFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final int yearEstablished;
  @override
  final String country;
  @override
  final String description;
  @override
  final String url;
  @override
  final String image;
  @override
  final bool hasTradingIncentive;
  @override
  final int trustScore;
  @override
  final int trustScoreRank;
  @override
  final double tradeVolume24HBtc;
  @override
  final double tradeVolume24HBtcNormalized;

  @override
  String toString() {
    return 'ExchangeModel(id: $id, name: $name, yearEstablished: $yearEstablished, country: $country, description: $description, url: $url, image: $image, hasTradingIncentive: $hasTradingIncentive, trustScore: $trustScore, trustScoreRank: $trustScoreRank, tradeVolume24HBtc: $tradeVolume24HBtc, tradeVolume24HBtcNormalized: $tradeVolume24HBtcNormalized)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ExchangeModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.yearEstablished, yearEstablished) ||
                other.yearEstablished == yearEstablished) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.url, url) || other.url == url) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.hasTradingIncentive, hasTradingIncentive) ||
                other.hasTradingIncentive == hasTradingIncentive) &&
            (identical(other.trustScore, trustScore) ||
                other.trustScore == trustScore) &&
            (identical(other.trustScoreRank, trustScoreRank) ||
                other.trustScoreRank == trustScoreRank) &&
            (identical(other.tradeVolume24HBtc, tradeVolume24HBtc) ||
                other.tradeVolume24HBtc == tradeVolume24HBtc) &&
            (identical(other.tradeVolume24HBtcNormalized,
                    tradeVolume24HBtcNormalized) ||
                other.tradeVolume24HBtcNormalized ==
                    tradeVolume24HBtcNormalized));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      yearEstablished,
      country,
      description,
      url,
      image,
      hasTradingIncentive,
      trustScore,
      trustScoreRank,
      tradeVolume24HBtc,
      tradeVolume24HBtcNormalized);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ExchangeModelCopyWith<_$_ExchangeModel> get copyWith =>
      __$$_ExchangeModelCopyWithImpl<_$_ExchangeModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ExchangeModelToJson(
      this,
    );
  }
}

abstract class _ExchangeModel implements ExchangeModel {
  const factory _ExchangeModel(
      {required final String id,
      required final String name,
      required final int yearEstablished,
      required final String country,
      required final String description,
      required final String url,
      required final String image,
      required final bool hasTradingIncentive,
      required final int trustScore,
      required final int trustScoreRank,
      required final double tradeVolume24HBtc,
      required final double tradeVolume24HBtcNormalized}) = _$_ExchangeModel;

  factory _ExchangeModel.fromJson(Map<String, dynamic> json) =
      _$_ExchangeModel.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  int get yearEstablished;
  @override
  String get country;
  @override
  String get description;
  @override
  String get url;
  @override
  String get image;
  @override
  bool get hasTradingIncentive;
  @override
  int get trustScore;
  @override
  int get trustScoreRank;
  @override
  double get tradeVolume24HBtc;
  @override
  double get tradeVolume24HBtcNormalized;
  @override
  @JsonKey(ignore: true)
  _$$_ExchangeModelCopyWith<_$_ExchangeModel> get copyWith =>
      throw _privateConstructorUsedError;
}
