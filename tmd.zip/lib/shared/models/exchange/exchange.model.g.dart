// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'exchange.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ExchangeModel _$$_ExchangeModelFromJson(Map json) => _$_ExchangeModel(
      id: json['id'] as String,
      name: json['name'] as String,
      yearEstablished: json['year_established'] as int,
      country: json['country'] as String,
      description: json['description'] as String,
      url: json['url'] as String,
      image: json['image'] as String,
      hasTradingIncentive: json['has_trading_incentive'] as bool,
      trustScore: json['trust_score'] as int,
      trustScoreRank: json['trust_score_rank'] as int,
      tradeVolume24HBtc: (json['trade_volume24_h_btc'] as num).toDouble(),
      tradeVolume24HBtcNormalized:
          (json['trade_volume24_h_btc_normalized'] as num).toDouble(),
    );

Map<String, dynamic> _$$_ExchangeModelToJson(_$_ExchangeModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'year_established': instance.yearEstablished,
      'country': instance.country,
      'description': instance.description,
      'url': instance.url,
      'image': instance.image,
      'has_trading_incentive': instance.hasTradingIncentive,
      'trust_score': instance.trustScore,
      'trust_score_rank': instance.trustScoreRank,
      'trade_volume24_h_btc': instance.tradeVolume24HBtc,
      'trade_volume24_h_btc_normalized': instance.tradeVolume24HBtcNormalized,
    };
