// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'exchange_api_item.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ExchangeApiItemModel _$$_ExchangeApiItemModelFromJson(Map json) =>
    _$_ExchangeApiItemModel(
      id: json['id'] as String,
      name: json['name'] as String,
    );

Map<String, dynamic> _$$_ExchangeApiItemModelToJson(
        _$_ExchangeApiItemModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
