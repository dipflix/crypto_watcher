// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'exchange_volume.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ExchangeVolumeModel _$ExchangeVolumeModelFromJson(Map<String, dynamic> json) {
  return _ExchangeVolumeModel.fromJson(json);
}

/// @nodoc
mixin _$ExchangeVolumeModel {
  String get name => throw _privateConstructorUsedError;
  String? get yearEstablished => throw _privateConstructorUsedError;
  String? get country => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get url => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get facebookUrl => throw _privateConstructorUsedError;
  String get redditUrl => throw _privateConstructorUsedError;
  String get telegramUrl => throw _privateConstructorUsedError;
  String get slackUrl => throw _privateConstructorUsedError;
  String get otherUrl1 => throw _privateConstructorUsedError;
  String get otherUrl2 => throw _privateConstructorUsedError;
  String get twitterHandle => throw _privateConstructorUsedError;
  bool get hasTradingIncentive => throw _privateConstructorUsedError;
  bool get centralized => throw _privateConstructorUsedError;
  String get publicNotice => throw _privateConstructorUsedError;
  String get alertNotice => throw _privateConstructorUsedError;
  String? get trustScore => throw _privateConstructorUsedError;
  int get trustScoreRank => throw _privateConstructorUsedError;
  double get tradeVolume24HBtc => throw _privateConstructorUsedError;
  double get tradeVolume24HBtcNormalized => throw _privateConstructorUsedError;
  List<TickerModel> get tickers => throw _privateConstructorUsedError;
  List<String>? get statusUpdates => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ExchangeVolumeModelCopyWith<ExchangeVolumeModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ExchangeVolumeModelCopyWith<$Res> {
  factory $ExchangeVolumeModelCopyWith(
          ExchangeVolumeModel value, $Res Function(ExchangeVolumeModel) then) =
      _$ExchangeVolumeModelCopyWithImpl<$Res, ExchangeVolumeModel>;
  @useResult
  $Res call(
      {String name,
      String? yearEstablished,
      String? country,
      String description,
      String url,
      String image,
      String facebookUrl,
      String redditUrl,
      String telegramUrl,
      String slackUrl,
      String otherUrl1,
      String otherUrl2,
      String twitterHandle,
      bool hasTradingIncentive,
      bool centralized,
      String publicNotice,
      String alertNotice,
      String? trustScore,
      int trustScoreRank,
      double tradeVolume24HBtc,
      double tradeVolume24HBtcNormalized,
      List<TickerModel> tickers,
      List<String>? statusUpdates});
}

/// @nodoc
class _$ExchangeVolumeModelCopyWithImpl<$Res, $Val extends ExchangeVolumeModel>
    implements $ExchangeVolumeModelCopyWith<$Res> {
  _$ExchangeVolumeModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? yearEstablished = freezed,
    Object? country = freezed,
    Object? description = null,
    Object? url = null,
    Object? image = null,
    Object? facebookUrl = null,
    Object? redditUrl = null,
    Object? telegramUrl = null,
    Object? slackUrl = null,
    Object? otherUrl1 = null,
    Object? otherUrl2 = null,
    Object? twitterHandle = null,
    Object? hasTradingIncentive = null,
    Object? centralized = null,
    Object? publicNotice = null,
    Object? alertNotice = null,
    Object? trustScore = freezed,
    Object? trustScoreRank = null,
    Object? tradeVolume24HBtc = null,
    Object? tradeVolume24HBtcNormalized = null,
    Object? tickers = null,
    Object? statusUpdates = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      yearEstablished: freezed == yearEstablished
          ? _value.yearEstablished
          : yearEstablished // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      url: null == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      facebookUrl: null == facebookUrl
          ? _value.facebookUrl
          : facebookUrl // ignore: cast_nullable_to_non_nullable
              as String,
      redditUrl: null == redditUrl
          ? _value.redditUrl
          : redditUrl // ignore: cast_nullable_to_non_nullable
              as String,
      telegramUrl: null == telegramUrl
          ? _value.telegramUrl
          : telegramUrl // ignore: cast_nullable_to_non_nullable
              as String,
      slackUrl: null == slackUrl
          ? _value.slackUrl
          : slackUrl // ignore: cast_nullable_to_non_nullable
              as String,
      otherUrl1: null == otherUrl1
          ? _value.otherUrl1
          : otherUrl1 // ignore: cast_nullable_to_non_nullable
              as String,
      otherUrl2: null == otherUrl2
          ? _value.otherUrl2
          : otherUrl2 // ignore: cast_nullable_to_non_nullable
              as String,
      twitterHandle: null == twitterHandle
          ? _value.twitterHandle
          : twitterHandle // ignore: cast_nullable_to_non_nullable
              as String,
      hasTradingIncentive: null == hasTradingIncentive
          ? _value.hasTradingIncentive
          : hasTradingIncentive // ignore: cast_nullable_to_non_nullable
              as bool,
      centralized: null == centralized
          ? _value.centralized
          : centralized // ignore: cast_nullable_to_non_nullable
              as bool,
      publicNotice: null == publicNotice
          ? _value.publicNotice
          : publicNotice // ignore: cast_nullable_to_non_nullable
              as String,
      alertNotice: null == alertNotice
          ? _value.alertNotice
          : alertNotice // ignore: cast_nullable_to_non_nullable
              as String,
      trustScore: freezed == trustScore
          ? _value.trustScore
          : trustScore // ignore: cast_nullable_to_non_nullable
              as String?,
      trustScoreRank: null == trustScoreRank
          ? _value.trustScoreRank
          : trustScoreRank // ignore: cast_nullable_to_non_nullable
              as int,
      tradeVolume24HBtc: null == tradeVolume24HBtc
          ? _value.tradeVolume24HBtc
          : tradeVolume24HBtc // ignore: cast_nullable_to_non_nullable
              as double,
      tradeVolume24HBtcNormalized: null == tradeVolume24HBtcNormalized
          ? _value.tradeVolume24HBtcNormalized
          : tradeVolume24HBtcNormalized // ignore: cast_nullable_to_non_nullable
              as double,
      tickers: null == tickers
          ? _value.tickers
          : tickers // ignore: cast_nullable_to_non_nullable
              as List<TickerModel>,
      statusUpdates: freezed == statusUpdates
          ? _value.statusUpdates
          : statusUpdates // ignore: cast_nullable_to_non_nullable
              as List<String>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ExchangeVolumeModelCopyWith<$Res>
    implements $ExchangeVolumeModelCopyWith<$Res> {
  factory _$$_ExchangeVolumeModelCopyWith(_$_ExchangeVolumeModel value,
          $Res Function(_$_ExchangeVolumeModel) then) =
      __$$_ExchangeVolumeModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String name,
      String? yearEstablished,
      String? country,
      String description,
      String url,
      String image,
      String facebookUrl,
      String redditUrl,
      String telegramUrl,
      String slackUrl,
      String otherUrl1,
      String otherUrl2,
      String twitterHandle,
      bool hasTradingIncentive,
      bool centralized,
      String publicNotice,
      String alertNotice,
      String? trustScore,
      int trustScoreRank,
      double tradeVolume24HBtc,
      double tradeVolume24HBtcNormalized,
      List<TickerModel> tickers,
      List<String>? statusUpdates});
}

/// @nodoc
class __$$_ExchangeVolumeModelCopyWithImpl<$Res>
    extends _$ExchangeVolumeModelCopyWithImpl<$Res, _$_ExchangeVolumeModel>
    implements _$$_ExchangeVolumeModelCopyWith<$Res> {
  __$$_ExchangeVolumeModelCopyWithImpl(_$_ExchangeVolumeModel _value,
      $Res Function(_$_ExchangeVolumeModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? yearEstablished = freezed,
    Object? country = freezed,
    Object? description = null,
    Object? url = null,
    Object? image = null,
    Object? facebookUrl = null,
    Object? redditUrl = null,
    Object? telegramUrl = null,
    Object? slackUrl = null,
    Object? otherUrl1 = null,
    Object? otherUrl2 = null,
    Object? twitterHandle = null,
    Object? hasTradingIncentive = null,
    Object? centralized = null,
    Object? publicNotice = null,
    Object? alertNotice = null,
    Object? trustScore = freezed,
    Object? trustScoreRank = null,
    Object? tradeVolume24HBtc = null,
    Object? tradeVolume24HBtcNormalized = null,
    Object? tickers = null,
    Object? statusUpdates = freezed,
  }) {
    return _then(_$_ExchangeVolumeModel(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      yearEstablished: freezed == yearEstablished
          ? _value.yearEstablished
          : yearEstablished // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      url: null == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      facebookUrl: null == facebookUrl
          ? _value.facebookUrl
          : facebookUrl // ignore: cast_nullable_to_non_nullable
              as String,
      redditUrl: null == redditUrl
          ? _value.redditUrl
          : redditUrl // ignore: cast_nullable_to_non_nullable
              as String,
      telegramUrl: null == telegramUrl
          ? _value.telegramUrl
          : telegramUrl // ignore: cast_nullable_to_non_nullable
              as String,
      slackUrl: null == slackUrl
          ? _value.slackUrl
          : slackUrl // ignore: cast_nullable_to_non_nullable
              as String,
      otherUrl1: null == otherUrl1
          ? _value.otherUrl1
          : otherUrl1 // ignore: cast_nullable_to_non_nullable
              as String,
      otherUrl2: null == otherUrl2
          ? _value.otherUrl2
          : otherUrl2 // ignore: cast_nullable_to_non_nullable
              as String,
      twitterHandle: null == twitterHandle
          ? _value.twitterHandle
          : twitterHandle // ignore: cast_nullable_to_non_nullable
              as String,
      hasTradingIncentive: null == hasTradingIncentive
          ? _value.hasTradingIncentive
          : hasTradingIncentive // ignore: cast_nullable_to_non_nullable
              as bool,
      centralized: null == centralized
          ? _value.centralized
          : centralized // ignore: cast_nullable_to_non_nullable
              as bool,
      publicNotice: null == publicNotice
          ? _value.publicNotice
          : publicNotice // ignore: cast_nullable_to_non_nullable
              as String,
      alertNotice: null == alertNotice
          ? _value.alertNotice
          : alertNotice // ignore: cast_nullable_to_non_nullable
              as String,
      trustScore: freezed == trustScore
          ? _value.trustScore
          : trustScore // ignore: cast_nullable_to_non_nullable
              as String?,
      trustScoreRank: null == trustScoreRank
          ? _value.trustScoreRank
          : trustScoreRank // ignore: cast_nullable_to_non_nullable
              as int,
      tradeVolume24HBtc: null == tradeVolume24HBtc
          ? _value.tradeVolume24HBtc
          : tradeVolume24HBtc // ignore: cast_nullable_to_non_nullable
              as double,
      tradeVolume24HBtcNormalized: null == tradeVolume24HBtcNormalized
          ? _value.tradeVolume24HBtcNormalized
          : tradeVolume24HBtcNormalized // ignore: cast_nullable_to_non_nullable
              as double,
      tickers: null == tickers
          ? _value._tickers
          : tickers // ignore: cast_nullable_to_non_nullable
              as List<TickerModel>,
      statusUpdates: freezed == statusUpdates
          ? _value._statusUpdates
          : statusUpdates // ignore: cast_nullable_to_non_nullable
              as List<String>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ExchangeVolumeModel implements _ExchangeVolumeModel {
  const _$_ExchangeVolumeModel(
      {required this.name,
      this.yearEstablished,
      this.country,
      required this.description,
      required this.url,
      required this.image,
      required this.facebookUrl,
      required this.redditUrl,
      required this.telegramUrl,
      required this.slackUrl,
      required this.otherUrl1,
      required this.otherUrl2,
      required this.twitterHandle,
      required this.hasTradingIncentive,
      required this.centralized,
      required this.publicNotice,
      required this.alertNotice,
      this.trustScore,
      required this.trustScoreRank,
      required this.tradeVolume24HBtc,
      required this.tradeVolume24HBtcNormalized,
      required final List<TickerModel> tickers,
      final List<String>? statusUpdates})
      : _tickers = tickers,
        _statusUpdates = statusUpdates;

  factory _$_ExchangeVolumeModel.fromJson(Map<String, dynamic> json) =>
      _$$_ExchangeVolumeModelFromJson(json);

  @override
  final String name;
  @override
  final String? yearEstablished;
  @override
  final String? country;
  @override
  final String description;
  @override
  final String url;
  @override
  final String image;
  @override
  final String facebookUrl;
  @override
  final String redditUrl;
  @override
  final String telegramUrl;
  @override
  final String slackUrl;
  @override
  final String otherUrl1;
  @override
  final String otherUrl2;
  @override
  final String twitterHandle;
  @override
  final bool hasTradingIncentive;
  @override
  final bool centralized;
  @override
  final String publicNotice;
  @override
  final String alertNotice;
  @override
  final String? trustScore;
  @override
  final int trustScoreRank;
  @override
  final double tradeVolume24HBtc;
  @override
  final double tradeVolume24HBtcNormalized;
  final List<TickerModel> _tickers;
  @override
  List<TickerModel> get tickers {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_tickers);
  }

  final List<String>? _statusUpdates;
  @override
  List<String>? get statusUpdates {
    final value = _statusUpdates;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'ExchangeVolumeModel(name: $name, yearEstablished: $yearEstablished, country: $country, description: $description, url: $url, image: $image, facebookUrl: $facebookUrl, redditUrl: $redditUrl, telegramUrl: $telegramUrl, slackUrl: $slackUrl, otherUrl1: $otherUrl1, otherUrl2: $otherUrl2, twitterHandle: $twitterHandle, hasTradingIncentive: $hasTradingIncentive, centralized: $centralized, publicNotice: $publicNotice, alertNotice: $alertNotice, trustScore: $trustScore, trustScoreRank: $trustScoreRank, tradeVolume24HBtc: $tradeVolume24HBtc, tradeVolume24HBtcNormalized: $tradeVolume24HBtcNormalized, tickers: $tickers, statusUpdates: $statusUpdates)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ExchangeVolumeModel &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.yearEstablished, yearEstablished) ||
                other.yearEstablished == yearEstablished) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.url, url) || other.url == url) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.facebookUrl, facebookUrl) ||
                other.facebookUrl == facebookUrl) &&
            (identical(other.redditUrl, redditUrl) ||
                other.redditUrl == redditUrl) &&
            (identical(other.telegramUrl, telegramUrl) ||
                other.telegramUrl == telegramUrl) &&
            (identical(other.slackUrl, slackUrl) ||
                other.slackUrl == slackUrl) &&
            (identical(other.otherUrl1, otherUrl1) ||
                other.otherUrl1 == otherUrl1) &&
            (identical(other.otherUrl2, otherUrl2) ||
                other.otherUrl2 == otherUrl2) &&
            (identical(other.twitterHandle, twitterHandle) ||
                other.twitterHandle == twitterHandle) &&
            (identical(other.hasTradingIncentive, hasTradingIncentive) ||
                other.hasTradingIncentive == hasTradingIncentive) &&
            (identical(other.centralized, centralized) ||
                other.centralized == centralized) &&
            (identical(other.publicNotice, publicNotice) ||
                other.publicNotice == publicNotice) &&
            (identical(other.alertNotice, alertNotice) ||
                other.alertNotice == alertNotice) &&
            (identical(other.trustScore, trustScore) ||
                other.trustScore == trustScore) &&
            (identical(other.trustScoreRank, trustScoreRank) ||
                other.trustScoreRank == trustScoreRank) &&
            (identical(other.tradeVolume24HBtc, tradeVolume24HBtc) ||
                other.tradeVolume24HBtc == tradeVolume24HBtc) &&
            (identical(other.tradeVolume24HBtcNormalized,
                    tradeVolume24HBtcNormalized) ||
                other.tradeVolume24HBtcNormalized ==
                    tradeVolume24HBtcNormalized) &&
            const DeepCollectionEquality().equals(other._tickers, _tickers) &&
            const DeepCollectionEquality()
                .equals(other._statusUpdates, _statusUpdates));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        name,
        yearEstablished,
        country,
        description,
        url,
        image,
        facebookUrl,
        redditUrl,
        telegramUrl,
        slackUrl,
        otherUrl1,
        otherUrl2,
        twitterHandle,
        hasTradingIncentive,
        centralized,
        publicNotice,
        alertNotice,
        trustScore,
        trustScoreRank,
        tradeVolume24HBtc,
        tradeVolume24HBtcNormalized,
        const DeepCollectionEquality().hash(_tickers),
        const DeepCollectionEquality().hash(_statusUpdates)
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ExchangeVolumeModelCopyWith<_$_ExchangeVolumeModel> get copyWith =>
      __$$_ExchangeVolumeModelCopyWithImpl<_$_ExchangeVolumeModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ExchangeVolumeModelToJson(
      this,
    );
  }
}

abstract class _ExchangeVolumeModel implements ExchangeVolumeModel {
  const factory _ExchangeVolumeModel(
      {required final String name,
      final String? yearEstablished,
      final String? country,
      required final String description,
      required final String url,
      required final String image,
      required final String facebookUrl,
      required final String redditUrl,
      required final String telegramUrl,
      required final String slackUrl,
      required final String otherUrl1,
      required final String otherUrl2,
      required final String twitterHandle,
      required final bool hasTradingIncentive,
      required final bool centralized,
      required final String publicNotice,
      required final String alertNotice,
      final String? trustScore,
      required final int trustScoreRank,
      required final double tradeVolume24HBtc,
      required final double tradeVolume24HBtcNormalized,
      required final List<TickerModel> tickers,
      final List<String>? statusUpdates}) = _$_ExchangeVolumeModel;

  factory _ExchangeVolumeModel.fromJson(Map<String, dynamic> json) =
      _$_ExchangeVolumeModel.fromJson;

  @override
  String get name;
  @override
  String? get yearEstablished;
  @override
  String? get country;
  @override
  String get description;
  @override
  String get url;
  @override
  String get image;
  @override
  String get facebookUrl;
  @override
  String get redditUrl;
  @override
  String get telegramUrl;
  @override
  String get slackUrl;
  @override
  String get otherUrl1;
  @override
  String get otherUrl2;
  @override
  String get twitterHandle;
  @override
  bool get hasTradingIncentive;
  @override
  bool get centralized;
  @override
  String get publicNotice;
  @override
  String get alertNotice;
  @override
  String? get trustScore;
  @override
  int get trustScoreRank;
  @override
  double get tradeVolume24HBtc;
  @override
  double get tradeVolume24HBtcNormalized;
  @override
  List<TickerModel> get tickers;
  @override
  List<String>? get statusUpdates;
  @override
  @JsonKey(ignore: true)
  _$$_ExchangeVolumeModelCopyWith<_$_ExchangeVolumeModel> get copyWith =>
      throw _privateConstructorUsedError;
}
