// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'exchange_volume.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ExchangeVolumeModel _$$_ExchangeVolumeModelFromJson(Map json) =>
    _$_ExchangeVolumeModel(
      name: json['name'] as String,
      yearEstablished: json['year_established'] as String?,
      country: json['country'] as String?,
      description: json['description'] as String,
      url: json['url'] as String,
      image: json['image'] as String,
      facebookUrl: json['facebook_url'] as String,
      redditUrl: json['reddit_url'] as String,
      telegramUrl: json['telegram_url'] as String,
      slackUrl: json['slack_url'] as String,
      otherUrl1: json['other_url1'] as String,
      otherUrl2: json['other_url2'] as String,
      twitterHandle: json['twitter_handle'] as String,
      hasTradingIncentive: json['has_trading_incentive'] as bool,
      centralized: json['centralized'] as bool,
      publicNotice: json['public_notice'] as String,
      alertNotice: json['alert_notice'] as String,
      trustScore: json['trust_score'] as String?,
      trustScoreRank: json['trust_score_rank'] as int,
      tradeVolume24HBtc: (json['trade_volume24_h_btc'] as num).toDouble(),
      tradeVolume24HBtcNormalized:
          (json['trade_volume24_h_btc_normalized'] as num).toDouble(),
      tickers: (json['tickers'] as List<dynamic>)
          .map((e) => TickerModel.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      statusUpdates: (json['status_updates'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$$_ExchangeVolumeModelToJson(
        _$_ExchangeVolumeModel instance) =>
    <String, dynamic>{
      'name': instance.name,
      'year_established': instance.yearEstablished,
      'country': instance.country,
      'description': instance.description,
      'url': instance.url,
      'image': instance.image,
      'facebook_url': instance.facebookUrl,
      'reddit_url': instance.redditUrl,
      'telegram_url': instance.telegramUrl,
      'slack_url': instance.slackUrl,
      'other_url1': instance.otherUrl1,
      'other_url2': instance.otherUrl2,
      'twitter_handle': instance.twitterHandle,
      'has_trading_incentive': instance.hasTradingIncentive,
      'centralized': instance.centralized,
      'public_notice': instance.publicNotice,
      'alert_notice': instance.alertNotice,
      'trust_score': instance.trustScore,
      'trust_score_rank': instance.trustScoreRank,
      'trade_volume24_h_btc': instance.tradeVolume24HBtc,
      'trade_volume24_h_btc_normalized': instance.tradeVolume24HBtcNormalized,
      'tickers': instance.tickers,
      'status_updates': instance.statusUpdates,
    };
