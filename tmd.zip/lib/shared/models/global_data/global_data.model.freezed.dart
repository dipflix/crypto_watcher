// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'global_data.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

GlobalModel _$GlobalModelFromJson(Map<String, dynamic> json) {
  return _GlobalModel.fromJson(json);
}

/// @nodoc
mixin _$GlobalModel {
  int get activeCryptocurrencies => throw _privateConstructorUsedError;
  int get upcomingIcos => throw _privateConstructorUsedError;
  int get ongoingIcos => throw _privateConstructorUsedError;
  int get endedIcos => throw _privateConstructorUsedError;
  int get markets => throw _privateConstructorUsedError;
  Map<String, double> get totalMarketCap => throw _privateConstructorUsedError;
  Map<String, double> get totalVolume => throw _privateConstructorUsedError;
  Map<String, double> get marketCapPercentage =>
      throw _privateConstructorUsedError;
  double get marketCapChangePercentage24HUsd =>
      throw _privateConstructorUsedError;
  int get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GlobalModelCopyWith<GlobalModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GlobalModelCopyWith<$Res> {
  factory $GlobalModelCopyWith(
          GlobalModel value, $Res Function(GlobalModel) then) =
      _$GlobalModelCopyWithImpl<$Res, GlobalModel>;
  @useResult
  $Res call(
      {int activeCryptocurrencies,
      int upcomingIcos,
      int ongoingIcos,
      int endedIcos,
      int markets,
      Map<String, double> totalMarketCap,
      Map<String, double> totalVolume,
      Map<String, double> marketCapPercentage,
      double marketCapChangePercentage24HUsd,
      int updatedAt});
}

/// @nodoc
class _$GlobalModelCopyWithImpl<$Res, $Val extends GlobalModel>
    implements $GlobalModelCopyWith<$Res> {
  _$GlobalModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? activeCryptocurrencies = null,
    Object? upcomingIcos = null,
    Object? ongoingIcos = null,
    Object? endedIcos = null,
    Object? markets = null,
    Object? totalMarketCap = null,
    Object? totalVolume = null,
    Object? marketCapPercentage = null,
    Object? marketCapChangePercentage24HUsd = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      activeCryptocurrencies: null == activeCryptocurrencies
          ? _value.activeCryptocurrencies
          : activeCryptocurrencies // ignore: cast_nullable_to_non_nullable
              as int,
      upcomingIcos: null == upcomingIcos
          ? _value.upcomingIcos
          : upcomingIcos // ignore: cast_nullable_to_non_nullable
              as int,
      ongoingIcos: null == ongoingIcos
          ? _value.ongoingIcos
          : ongoingIcos // ignore: cast_nullable_to_non_nullable
              as int,
      endedIcos: null == endedIcos
          ? _value.endedIcos
          : endedIcos // ignore: cast_nullable_to_non_nullable
              as int,
      markets: null == markets
          ? _value.markets
          : markets // ignore: cast_nullable_to_non_nullable
              as int,
      totalMarketCap: null == totalMarketCap
          ? _value.totalMarketCap
          : totalMarketCap // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      totalVolume: null == totalVolume
          ? _value.totalVolume
          : totalVolume // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      marketCapPercentage: null == marketCapPercentage
          ? _value.marketCapPercentage
          : marketCapPercentage // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      marketCapChangePercentage24HUsd: null == marketCapChangePercentage24HUsd
          ? _value.marketCapChangePercentage24HUsd
          : marketCapChangePercentage24HUsd // ignore: cast_nullable_to_non_nullable
              as double,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_GlobalModelCopyWith<$Res>
    implements $GlobalModelCopyWith<$Res> {
  factory _$$_GlobalModelCopyWith(
          _$_GlobalModel value, $Res Function(_$_GlobalModel) then) =
      __$$_GlobalModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int activeCryptocurrencies,
      int upcomingIcos,
      int ongoingIcos,
      int endedIcos,
      int markets,
      Map<String, double> totalMarketCap,
      Map<String, double> totalVolume,
      Map<String, double> marketCapPercentage,
      double marketCapChangePercentage24HUsd,
      int updatedAt});
}

/// @nodoc
class __$$_GlobalModelCopyWithImpl<$Res>
    extends _$GlobalModelCopyWithImpl<$Res, _$_GlobalModel>
    implements _$$_GlobalModelCopyWith<$Res> {
  __$$_GlobalModelCopyWithImpl(
      _$_GlobalModel _value, $Res Function(_$_GlobalModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? activeCryptocurrencies = null,
    Object? upcomingIcos = null,
    Object? ongoingIcos = null,
    Object? endedIcos = null,
    Object? markets = null,
    Object? totalMarketCap = null,
    Object? totalVolume = null,
    Object? marketCapPercentage = null,
    Object? marketCapChangePercentage24HUsd = null,
    Object? updatedAt = null,
  }) {
    return _then(_$_GlobalModel(
      activeCryptocurrencies: null == activeCryptocurrencies
          ? _value.activeCryptocurrencies
          : activeCryptocurrencies // ignore: cast_nullable_to_non_nullable
              as int,
      upcomingIcos: null == upcomingIcos
          ? _value.upcomingIcos
          : upcomingIcos // ignore: cast_nullable_to_non_nullable
              as int,
      ongoingIcos: null == ongoingIcos
          ? _value.ongoingIcos
          : ongoingIcos // ignore: cast_nullable_to_non_nullable
              as int,
      endedIcos: null == endedIcos
          ? _value.endedIcos
          : endedIcos // ignore: cast_nullable_to_non_nullable
              as int,
      markets: null == markets
          ? _value.markets
          : markets // ignore: cast_nullable_to_non_nullable
              as int,
      totalMarketCap: null == totalMarketCap
          ? _value._totalMarketCap
          : totalMarketCap // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      totalVolume: null == totalVolume
          ? _value._totalVolume
          : totalVolume // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      marketCapPercentage: null == marketCapPercentage
          ? _value._marketCapPercentage
          : marketCapPercentage // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      marketCapChangePercentage24HUsd: null == marketCapChangePercentage24HUsd
          ? _value.marketCapChangePercentage24HUsd
          : marketCapChangePercentage24HUsd // ignore: cast_nullable_to_non_nullable
              as double,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_GlobalModel implements _GlobalModel {
  const _$_GlobalModel(
      {required this.activeCryptocurrencies,
      required this.upcomingIcos,
      required this.ongoingIcos,
      required this.endedIcos,
      required this.markets,
      required final Map<String, double> totalMarketCap,
      required final Map<String, double> totalVolume,
      required final Map<String, double> marketCapPercentage,
      required this.marketCapChangePercentage24HUsd,
      required this.updatedAt})
      : _totalMarketCap = totalMarketCap,
        _totalVolume = totalVolume,
        _marketCapPercentage = marketCapPercentage;

  factory _$_GlobalModel.fromJson(Map<String, dynamic> json) =>
      _$$_GlobalModelFromJson(json);

  @override
  final int activeCryptocurrencies;
  @override
  final int upcomingIcos;
  @override
  final int ongoingIcos;
  @override
  final int endedIcos;
  @override
  final int markets;
  final Map<String, double> _totalMarketCap;
  @override
  Map<String, double> get totalMarketCap {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_totalMarketCap);
  }

  final Map<String, double> _totalVolume;
  @override
  Map<String, double> get totalVolume {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_totalVolume);
  }

  final Map<String, double> _marketCapPercentage;
  @override
  Map<String, double> get marketCapPercentage {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_marketCapPercentage);
  }

  @override
  final double marketCapChangePercentage24HUsd;
  @override
  final int updatedAt;

  @override
  String toString() {
    return 'GlobalModel(activeCryptocurrencies: $activeCryptocurrencies, upcomingIcos: $upcomingIcos, ongoingIcos: $ongoingIcos, endedIcos: $endedIcos, markets: $markets, totalMarketCap: $totalMarketCap, totalVolume: $totalVolume, marketCapPercentage: $marketCapPercentage, marketCapChangePercentage24HUsd: $marketCapChangePercentage24HUsd, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_GlobalModel &&
            (identical(other.activeCryptocurrencies, activeCryptocurrencies) ||
                other.activeCryptocurrencies == activeCryptocurrencies) &&
            (identical(other.upcomingIcos, upcomingIcos) ||
                other.upcomingIcos == upcomingIcos) &&
            (identical(other.ongoingIcos, ongoingIcos) ||
                other.ongoingIcos == ongoingIcos) &&
            (identical(other.endedIcos, endedIcos) ||
                other.endedIcos == endedIcos) &&
            (identical(other.markets, markets) || other.markets == markets) &&
            const DeepCollectionEquality()
                .equals(other._totalMarketCap, _totalMarketCap) &&
            const DeepCollectionEquality()
                .equals(other._totalVolume, _totalVolume) &&
            const DeepCollectionEquality()
                .equals(other._marketCapPercentage, _marketCapPercentage) &&
            (identical(other.marketCapChangePercentage24HUsd,
                    marketCapChangePercentage24HUsd) ||
                other.marketCapChangePercentage24HUsd ==
                    marketCapChangePercentage24HUsd) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      activeCryptocurrencies,
      upcomingIcos,
      ongoingIcos,
      endedIcos,
      markets,
      const DeepCollectionEquality().hash(_totalMarketCap),
      const DeepCollectionEquality().hash(_totalVolume),
      const DeepCollectionEquality().hash(_marketCapPercentage),
      marketCapChangePercentage24HUsd,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_GlobalModelCopyWith<_$_GlobalModel> get copyWith =>
      __$$_GlobalModelCopyWithImpl<_$_GlobalModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_GlobalModelToJson(
      this,
    );
  }
}

abstract class _GlobalModel implements GlobalModel {
  const factory _GlobalModel(
      {required final int activeCryptocurrencies,
      required final int upcomingIcos,
      required final int ongoingIcos,
      required final int endedIcos,
      required final int markets,
      required final Map<String, double> totalMarketCap,
      required final Map<String, double> totalVolume,
      required final Map<String, double> marketCapPercentage,
      required final double marketCapChangePercentage24HUsd,
      required final int updatedAt}) = _$_GlobalModel;

  factory _GlobalModel.fromJson(Map<String, dynamic> json) =
      _$_GlobalModel.fromJson;

  @override
  int get activeCryptocurrencies;
  @override
  int get upcomingIcos;
  @override
  int get ongoingIcos;
  @override
  int get endedIcos;
  @override
  int get markets;
  @override
  Map<String, double> get totalMarketCap;
  @override
  Map<String, double> get totalVolume;
  @override
  Map<String, double> get marketCapPercentage;
  @override
  double get marketCapChangePercentage24HUsd;
  @override
  int get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$_GlobalModelCopyWith<_$_GlobalModel> get copyWith =>
      throw _privateConstructorUsedError;
}
