// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'global_data.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_GlobalModel _$$_GlobalModelFromJson(Map json) => _$_GlobalModel(
      activeCryptocurrencies: json['active_cryptocurrencies'] as int,
      upcomingIcos: json['upcoming_icos'] as int,
      ongoingIcos: json['ongoing_icos'] as int,
      endedIcos: json['ended_icos'] as int,
      markets: json['markets'] as int,
      totalMarketCap: (json['total_market_cap'] as Map).map(
        (k, e) => MapEntry(k as String, (e as num).toDouble()),
      ),
      totalVolume: (json['total_volume'] as Map).map(
        (k, e) => MapEntry(k as String, (e as num).toDouble()),
      ),
      marketCapPercentage: (json['market_cap_percentage'] as Map).map(
        (k, e) => MapEntry(k as String, (e as num).toDouble()),
      ),
      marketCapChangePercentage24HUsd:
          (json['market_cap_change_percentage24_h_usd'] as num).toDouble(),
      updatedAt: json['updated_at'] as int,
    );

Map<String, dynamic> _$$_GlobalModelToJson(_$_GlobalModel instance) =>
    <String, dynamic>{
      'active_cryptocurrencies': instance.activeCryptocurrencies,
      'upcoming_icos': instance.upcomingIcos,
      'ongoing_icos': instance.ongoingIcos,
      'ended_icos': instance.endedIcos,
      'markets': instance.markets,
      'total_market_cap': instance.totalMarketCap,
      'total_volume': instance.totalVolume,
      'market_cap_percentage': instance.marketCapPercentage,
      'market_cap_change_percentage24_h_usd':
          instance.marketCapChangePercentage24HUsd,
      'updated_at': instance.updatedAt,
    };
