// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'links.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

LinksModel _$LinksModelFromJson(Map<String, dynamic> json) {
  return _LinksModel.fromJson(json);
}

/// @nodoc
mixin _$LinksModel {
  List<String> get homepage => throw _privateConstructorUsedError;
  List<String> get blockchainSite => throw _privateConstructorUsedError;
  List<String> get officialForumUrl => throw _privateConstructorUsedError;
  List<String> get chatUrl => throw _privateConstructorUsedError;
  List<String> get announcementUrl => throw _privateConstructorUsedError;
  String get twitterScreenName => throw _privateConstructorUsedError;
  String get facebookUsername => throw _privateConstructorUsedError;
  int get bitcointalkThreadIdentifier => throw _privateConstructorUsedError;
  String get telegramChannelIdentifier => throw _privateConstructorUsedError;
  String get subredditUrl => throw _privateConstructorUsedError;
  RepositoryUrlModel get reposUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $LinksModelCopyWith<LinksModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LinksModelCopyWith<$Res> {
  factory $LinksModelCopyWith(
          LinksModel value, $Res Function(LinksModel) then) =
      _$LinksModelCopyWithImpl<$Res, LinksModel>;
  @useResult
  $Res call(
      {List<String> homepage,
      List<String> blockchainSite,
      List<String> officialForumUrl,
      List<String> chatUrl,
      List<String> announcementUrl,
      String twitterScreenName,
      String facebookUsername,
      int bitcointalkThreadIdentifier,
      String telegramChannelIdentifier,
      String subredditUrl,
      RepositoryUrlModel reposUrl});

  $RepositoryUrlModelCopyWith<$Res> get reposUrl;
}

/// @nodoc
class _$LinksModelCopyWithImpl<$Res, $Val extends LinksModel>
    implements $LinksModelCopyWith<$Res> {
  _$LinksModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? homepage = null,
    Object? blockchainSite = null,
    Object? officialForumUrl = null,
    Object? chatUrl = null,
    Object? announcementUrl = null,
    Object? twitterScreenName = null,
    Object? facebookUsername = null,
    Object? bitcointalkThreadIdentifier = null,
    Object? telegramChannelIdentifier = null,
    Object? subredditUrl = null,
    Object? reposUrl = null,
  }) {
    return _then(_value.copyWith(
      homepage: null == homepage
          ? _value.homepage
          : homepage // ignore: cast_nullable_to_non_nullable
              as List<String>,
      blockchainSite: null == blockchainSite
          ? _value.blockchainSite
          : blockchainSite // ignore: cast_nullable_to_non_nullable
              as List<String>,
      officialForumUrl: null == officialForumUrl
          ? _value.officialForumUrl
          : officialForumUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
      chatUrl: null == chatUrl
          ? _value.chatUrl
          : chatUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
      announcementUrl: null == announcementUrl
          ? _value.announcementUrl
          : announcementUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
      twitterScreenName: null == twitterScreenName
          ? _value.twitterScreenName
          : twitterScreenName // ignore: cast_nullable_to_non_nullable
              as String,
      facebookUsername: null == facebookUsername
          ? _value.facebookUsername
          : facebookUsername // ignore: cast_nullable_to_non_nullable
              as String,
      bitcointalkThreadIdentifier: null == bitcointalkThreadIdentifier
          ? _value.bitcointalkThreadIdentifier
          : bitcointalkThreadIdentifier // ignore: cast_nullable_to_non_nullable
              as int,
      telegramChannelIdentifier: null == telegramChannelIdentifier
          ? _value.telegramChannelIdentifier
          : telegramChannelIdentifier // ignore: cast_nullable_to_non_nullable
              as String,
      subredditUrl: null == subredditUrl
          ? _value.subredditUrl
          : subredditUrl // ignore: cast_nullable_to_non_nullable
              as String,
      reposUrl: null == reposUrl
          ? _value.reposUrl
          : reposUrl // ignore: cast_nullable_to_non_nullable
              as RepositoryUrlModel,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $RepositoryUrlModelCopyWith<$Res> get reposUrl {
    return $RepositoryUrlModelCopyWith<$Res>(_value.reposUrl, (value) {
      return _then(_value.copyWith(reposUrl: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_LinksModelCopyWith<$Res>
    implements $LinksModelCopyWith<$Res> {
  factory _$$_LinksModelCopyWith(
          _$_LinksModel value, $Res Function(_$_LinksModel) then) =
      __$$_LinksModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<String> homepage,
      List<String> blockchainSite,
      List<String> officialForumUrl,
      List<String> chatUrl,
      List<String> announcementUrl,
      String twitterScreenName,
      String facebookUsername,
      int bitcointalkThreadIdentifier,
      String telegramChannelIdentifier,
      String subredditUrl,
      RepositoryUrlModel reposUrl});

  @override
  $RepositoryUrlModelCopyWith<$Res> get reposUrl;
}

/// @nodoc
class __$$_LinksModelCopyWithImpl<$Res>
    extends _$LinksModelCopyWithImpl<$Res, _$_LinksModel>
    implements _$$_LinksModelCopyWith<$Res> {
  __$$_LinksModelCopyWithImpl(
      _$_LinksModel _value, $Res Function(_$_LinksModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? homepage = null,
    Object? blockchainSite = null,
    Object? officialForumUrl = null,
    Object? chatUrl = null,
    Object? announcementUrl = null,
    Object? twitterScreenName = null,
    Object? facebookUsername = null,
    Object? bitcointalkThreadIdentifier = null,
    Object? telegramChannelIdentifier = null,
    Object? subredditUrl = null,
    Object? reposUrl = null,
  }) {
    return _then(_$_LinksModel(
      homepage: null == homepage
          ? _value._homepage
          : homepage // ignore: cast_nullable_to_non_nullable
              as List<String>,
      blockchainSite: null == blockchainSite
          ? _value._blockchainSite
          : blockchainSite // ignore: cast_nullable_to_non_nullable
              as List<String>,
      officialForumUrl: null == officialForumUrl
          ? _value._officialForumUrl
          : officialForumUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
      chatUrl: null == chatUrl
          ? _value._chatUrl
          : chatUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
      announcementUrl: null == announcementUrl
          ? _value._announcementUrl
          : announcementUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
      twitterScreenName: null == twitterScreenName
          ? _value.twitterScreenName
          : twitterScreenName // ignore: cast_nullable_to_non_nullable
              as String,
      facebookUsername: null == facebookUsername
          ? _value.facebookUsername
          : facebookUsername // ignore: cast_nullable_to_non_nullable
              as String,
      bitcointalkThreadIdentifier: null == bitcointalkThreadIdentifier
          ? _value.bitcointalkThreadIdentifier
          : bitcointalkThreadIdentifier // ignore: cast_nullable_to_non_nullable
              as int,
      telegramChannelIdentifier: null == telegramChannelIdentifier
          ? _value.telegramChannelIdentifier
          : telegramChannelIdentifier // ignore: cast_nullable_to_non_nullable
              as String,
      subredditUrl: null == subredditUrl
          ? _value.subredditUrl
          : subredditUrl // ignore: cast_nullable_to_non_nullable
              as String,
      reposUrl: null == reposUrl
          ? _value.reposUrl
          : reposUrl // ignore: cast_nullable_to_non_nullable
              as RepositoryUrlModel,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_LinksModel implements _LinksModel {
  const _$_LinksModel(
      {required final List<String> homepage,
      required final List<String> blockchainSite,
      required final List<String> officialForumUrl,
      required final List<String> chatUrl,
      required final List<String> announcementUrl,
      required this.twitterScreenName,
      required this.facebookUsername,
      required this.bitcointalkThreadIdentifier,
      required this.telegramChannelIdentifier,
      required this.subredditUrl,
      required this.reposUrl})
      : _homepage = homepage,
        _blockchainSite = blockchainSite,
        _officialForumUrl = officialForumUrl,
        _chatUrl = chatUrl,
        _announcementUrl = announcementUrl;

  factory _$_LinksModel.fromJson(Map<String, dynamic> json) =>
      _$$_LinksModelFromJson(json);

  final List<String> _homepage;
  @override
  List<String> get homepage {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_homepage);
  }

  final List<String> _blockchainSite;
  @override
  List<String> get blockchainSite {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_blockchainSite);
  }

  final List<String> _officialForumUrl;
  @override
  List<String> get officialForumUrl {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_officialForumUrl);
  }

  final List<String> _chatUrl;
  @override
  List<String> get chatUrl {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_chatUrl);
  }

  final List<String> _announcementUrl;
  @override
  List<String> get announcementUrl {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_announcementUrl);
  }

  @override
  final String twitterScreenName;
  @override
  final String facebookUsername;
  @override
  final int bitcointalkThreadIdentifier;
  @override
  final String telegramChannelIdentifier;
  @override
  final String subredditUrl;
  @override
  final RepositoryUrlModel reposUrl;

  @override
  String toString() {
    return 'LinksModel(homepage: $homepage, blockchainSite: $blockchainSite, officialForumUrl: $officialForumUrl, chatUrl: $chatUrl, announcementUrl: $announcementUrl, twitterScreenName: $twitterScreenName, facebookUsername: $facebookUsername, bitcointalkThreadIdentifier: $bitcointalkThreadIdentifier, telegramChannelIdentifier: $telegramChannelIdentifier, subredditUrl: $subredditUrl, reposUrl: $reposUrl)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_LinksModel &&
            const DeepCollectionEquality().equals(other._homepage, _homepage) &&
            const DeepCollectionEquality()
                .equals(other._blockchainSite, _blockchainSite) &&
            const DeepCollectionEquality()
                .equals(other._officialForumUrl, _officialForumUrl) &&
            const DeepCollectionEquality().equals(other._chatUrl, _chatUrl) &&
            const DeepCollectionEquality()
                .equals(other._announcementUrl, _announcementUrl) &&
            (identical(other.twitterScreenName, twitterScreenName) ||
                other.twitterScreenName == twitterScreenName) &&
            (identical(other.facebookUsername, facebookUsername) ||
                other.facebookUsername == facebookUsername) &&
            (identical(other.bitcointalkThreadIdentifier,
                    bitcointalkThreadIdentifier) ||
                other.bitcointalkThreadIdentifier ==
                    bitcointalkThreadIdentifier) &&
            (identical(other.telegramChannelIdentifier,
                    telegramChannelIdentifier) ||
                other.telegramChannelIdentifier == telegramChannelIdentifier) &&
            (identical(other.subredditUrl, subredditUrl) ||
                other.subredditUrl == subredditUrl) &&
            (identical(other.reposUrl, reposUrl) ||
                other.reposUrl == reposUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_homepage),
      const DeepCollectionEquality().hash(_blockchainSite),
      const DeepCollectionEquality().hash(_officialForumUrl),
      const DeepCollectionEquality().hash(_chatUrl),
      const DeepCollectionEquality().hash(_announcementUrl),
      twitterScreenName,
      facebookUsername,
      bitcointalkThreadIdentifier,
      telegramChannelIdentifier,
      subredditUrl,
      reposUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_LinksModelCopyWith<_$_LinksModel> get copyWith =>
      __$$_LinksModelCopyWithImpl<_$_LinksModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_LinksModelToJson(
      this,
    );
  }
}

abstract class _LinksModel implements LinksModel {
  const factory _LinksModel(
      {required final List<String> homepage,
      required final List<String> blockchainSite,
      required final List<String> officialForumUrl,
      required final List<String> chatUrl,
      required final List<String> announcementUrl,
      required final String twitterScreenName,
      required final String facebookUsername,
      required final int bitcointalkThreadIdentifier,
      required final String telegramChannelIdentifier,
      required final String subredditUrl,
      required final RepositoryUrlModel reposUrl}) = _$_LinksModel;

  factory _LinksModel.fromJson(Map<String, dynamic> json) =
      _$_LinksModel.fromJson;

  @override
  List<String> get homepage;
  @override
  List<String> get blockchainSite;
  @override
  List<String> get officialForumUrl;
  @override
  List<String> get chatUrl;
  @override
  List<String> get announcementUrl;
  @override
  String get twitterScreenName;
  @override
  String get facebookUsername;
  @override
  int get bitcointalkThreadIdentifier;
  @override
  String get telegramChannelIdentifier;
  @override
  String get subredditUrl;
  @override
  RepositoryUrlModel get reposUrl;
  @override
  @JsonKey(ignore: true)
  _$$_LinksModelCopyWith<_$_LinksModel> get copyWith =>
      throw _privateConstructorUsedError;
}
