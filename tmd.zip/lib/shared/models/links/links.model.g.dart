// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'links.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_LinksModel _$$_LinksModelFromJson(Map json) => _$_LinksModel(
      homepage:
          (json['homepage'] as List<dynamic>).map((e) => e as String).toList(),
      blockchainSite: (json['blockchain_site'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      officialForumUrl: (json['official_forum_url'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      chatUrl:
          (json['chat_url'] as List<dynamic>).map((e) => e as String).toList(),
      announcementUrl: (json['announcement_url'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      twitterScreenName: json['twitter_screen_name'] as String,
      facebookUsername: json['facebook_username'] as String,
      bitcointalkThreadIdentifier: json['bitcointalk_thread_identifier'] as int,
      telegramChannelIdentifier: json['telegram_channel_identifier'] as String,
      subredditUrl: json['subreddit_url'] as String,
      reposUrl: RepositoryUrlModel.fromJson(
          Map<String, dynamic>.from(json['repos_url'] as Map)),
    );

Map<String, dynamic> _$$_LinksModelToJson(_$_LinksModel instance) =>
    <String, dynamic>{
      'homepage': instance.homepage,
      'blockchain_site': instance.blockchainSite,
      'official_forum_url': instance.officialForumUrl,
      'chat_url': instance.chatUrl,
      'announcement_url': instance.announcementUrl,
      'twitter_screen_name': instance.twitterScreenName,
      'facebook_username': instance.facebookUsername,
      'bitcointalk_thread_identifier': instance.bitcointalkThreadIdentifier,
      'telegram_channel_identifier': instance.telegramChannelIdentifier,
      'subreddit_url': instance.subredditUrl,
      'repos_url': instance.reposUrl,
    };
