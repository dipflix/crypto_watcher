// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'market.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MarketModel _$MarketModelFromJson(Map<String, dynamic> json) {
  return _MarketModel.fromJson(json);
}

/// @nodoc
mixin _$MarketModel {
  String get id => throw _privateConstructorUsedError;
  String get symbol => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  double get currentPrice => throw _privateConstructorUsedError;
  int get marketCap => throw _privateConstructorUsedError;
  int? get marketCapRank => throw _privateConstructorUsedError;
  int? get fullyDilutedValuation => throw _privateConstructorUsedError;
  double? get totalVolume => throw _privateConstructorUsedError;
  double? get high24H => throw _privateConstructorUsedError;
  double? get low24H => throw _privateConstructorUsedError;
  @JsonKey(name: 'price_change_24h')
  double? get priceChange => throw _privateConstructorUsedError;
  @JsonKey(name: 'price_change_percentage_24h')
  double get priceChangePercentage => throw _privateConstructorUsedError;
  double? get marketCapChange24H => throw _privateConstructorUsedError;
  double? get marketCapChangePercentage24H =>
      throw _privateConstructorUsedError;
  double? get circulatingSupply => throw _privateConstructorUsedError;
  double? get totalSupply => throw _privateConstructorUsedError;
  double? get maxSupply => throw _privateConstructorUsedError;
  double? get ath => throw _privateConstructorUsedError;
  double? get athChangePercentage => throw _privateConstructorUsedError;
  DateTime? get athDate => throw _privateConstructorUsedError;
  double? get atl => throw _privateConstructorUsedError;
  double? get atlChangePercentage => throw _privateConstructorUsedError;
  DateTime? get atlDate => throw _privateConstructorUsedError;
  DateTime? get lastUpdated => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MarketModelCopyWith<MarketModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MarketModelCopyWith<$Res> {
  factory $MarketModelCopyWith(
          MarketModel value, $Res Function(MarketModel) then) =
      _$MarketModelCopyWithImpl<$Res, MarketModel>;
  @useResult
  $Res call(
      {String id,
      String symbol,
      String name,
      String image,
      double currentPrice,
      int marketCap,
      int? marketCapRank,
      int? fullyDilutedValuation,
      double? totalVolume,
      double? high24H,
      double? low24H,
      @JsonKey(name: 'price_change_24h')
          double? priceChange,
      @JsonKey(name: 'price_change_percentage_24h')
          double priceChangePercentage,
      double? marketCapChange24H,
      double? marketCapChangePercentage24H,
      double? circulatingSupply,
      double? totalSupply,
      double? maxSupply,
      double? ath,
      double? athChangePercentage,
      DateTime? athDate,
      double? atl,
      double? atlChangePercentage,
      DateTime? atlDate,
      DateTime? lastUpdated});
}

/// @nodoc
class _$MarketModelCopyWithImpl<$Res, $Val extends MarketModel>
    implements $MarketModelCopyWith<$Res> {
  _$MarketModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? symbol = null,
    Object? name = null,
    Object? image = null,
    Object? currentPrice = null,
    Object? marketCap = null,
    Object? marketCapRank = freezed,
    Object? fullyDilutedValuation = freezed,
    Object? totalVolume = freezed,
    Object? high24H = freezed,
    Object? low24H = freezed,
    Object? priceChange = freezed,
    Object? priceChangePercentage = null,
    Object? marketCapChange24H = freezed,
    Object? marketCapChangePercentage24H = freezed,
    Object? circulatingSupply = freezed,
    Object? totalSupply = freezed,
    Object? maxSupply = freezed,
    Object? ath = freezed,
    Object? athChangePercentage = freezed,
    Object? athDate = freezed,
    Object? atl = freezed,
    Object? atlChangePercentage = freezed,
    Object? atlDate = freezed,
    Object? lastUpdated = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      symbol: null == symbol
          ? _value.symbol
          : symbol // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      currentPrice: null == currentPrice
          ? _value.currentPrice
          : currentPrice // ignore: cast_nullable_to_non_nullable
              as double,
      marketCap: null == marketCap
          ? _value.marketCap
          : marketCap // ignore: cast_nullable_to_non_nullable
              as int,
      marketCapRank: freezed == marketCapRank
          ? _value.marketCapRank
          : marketCapRank // ignore: cast_nullable_to_non_nullable
              as int?,
      fullyDilutedValuation: freezed == fullyDilutedValuation
          ? _value.fullyDilutedValuation
          : fullyDilutedValuation // ignore: cast_nullable_to_non_nullable
              as int?,
      totalVolume: freezed == totalVolume
          ? _value.totalVolume
          : totalVolume // ignore: cast_nullable_to_non_nullable
              as double?,
      high24H: freezed == high24H
          ? _value.high24H
          : high24H // ignore: cast_nullable_to_non_nullable
              as double?,
      low24H: freezed == low24H
          ? _value.low24H
          : low24H // ignore: cast_nullable_to_non_nullable
              as double?,
      priceChange: freezed == priceChange
          ? _value.priceChange
          : priceChange // ignore: cast_nullable_to_non_nullable
              as double?,
      priceChangePercentage: null == priceChangePercentage
          ? _value.priceChangePercentage
          : priceChangePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      marketCapChange24H: freezed == marketCapChange24H
          ? _value.marketCapChange24H
          : marketCapChange24H // ignore: cast_nullable_to_non_nullable
              as double?,
      marketCapChangePercentage24H: freezed == marketCapChangePercentage24H
          ? _value.marketCapChangePercentage24H
          : marketCapChangePercentage24H // ignore: cast_nullable_to_non_nullable
              as double?,
      circulatingSupply: freezed == circulatingSupply
          ? _value.circulatingSupply
          : circulatingSupply // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSupply: freezed == totalSupply
          ? _value.totalSupply
          : totalSupply // ignore: cast_nullable_to_non_nullable
              as double?,
      maxSupply: freezed == maxSupply
          ? _value.maxSupply
          : maxSupply // ignore: cast_nullable_to_non_nullable
              as double?,
      ath: freezed == ath
          ? _value.ath
          : ath // ignore: cast_nullable_to_non_nullable
              as double?,
      athChangePercentage: freezed == athChangePercentage
          ? _value.athChangePercentage
          : athChangePercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      athDate: freezed == athDate
          ? _value.athDate
          : athDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      atl: freezed == atl
          ? _value.atl
          : atl // ignore: cast_nullable_to_non_nullable
              as double?,
      atlChangePercentage: freezed == atlChangePercentage
          ? _value.atlChangePercentage
          : atlChangePercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      atlDate: freezed == atlDate
          ? _value.atlDate
          : atlDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      lastUpdated: freezed == lastUpdated
          ? _value.lastUpdated
          : lastUpdated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MarketModelCopyWith<$Res>
    implements $MarketModelCopyWith<$Res> {
  factory _$$_MarketModelCopyWith(
          _$_MarketModel value, $Res Function(_$_MarketModel) then) =
      __$$_MarketModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String symbol,
      String name,
      String image,
      double currentPrice,
      int marketCap,
      int? marketCapRank,
      int? fullyDilutedValuation,
      double? totalVolume,
      double? high24H,
      double? low24H,
      @JsonKey(name: 'price_change_24h')
          double? priceChange,
      @JsonKey(name: 'price_change_percentage_24h')
          double priceChangePercentage,
      double? marketCapChange24H,
      double? marketCapChangePercentage24H,
      double? circulatingSupply,
      double? totalSupply,
      double? maxSupply,
      double? ath,
      double? athChangePercentage,
      DateTime? athDate,
      double? atl,
      double? atlChangePercentage,
      DateTime? atlDate,
      DateTime? lastUpdated});
}

/// @nodoc
class __$$_MarketModelCopyWithImpl<$Res>
    extends _$MarketModelCopyWithImpl<$Res, _$_MarketModel>
    implements _$$_MarketModelCopyWith<$Res> {
  __$$_MarketModelCopyWithImpl(
      _$_MarketModel _value, $Res Function(_$_MarketModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? symbol = null,
    Object? name = null,
    Object? image = null,
    Object? currentPrice = null,
    Object? marketCap = null,
    Object? marketCapRank = freezed,
    Object? fullyDilutedValuation = freezed,
    Object? totalVolume = freezed,
    Object? high24H = freezed,
    Object? low24H = freezed,
    Object? priceChange = freezed,
    Object? priceChangePercentage = null,
    Object? marketCapChange24H = freezed,
    Object? marketCapChangePercentage24H = freezed,
    Object? circulatingSupply = freezed,
    Object? totalSupply = freezed,
    Object? maxSupply = freezed,
    Object? ath = freezed,
    Object? athChangePercentage = freezed,
    Object? athDate = freezed,
    Object? atl = freezed,
    Object? atlChangePercentage = freezed,
    Object? atlDate = freezed,
    Object? lastUpdated = freezed,
  }) {
    return _then(_$_MarketModel(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      symbol: null == symbol
          ? _value.symbol
          : symbol // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      currentPrice: null == currentPrice
          ? _value.currentPrice
          : currentPrice // ignore: cast_nullable_to_non_nullable
              as double,
      marketCap: null == marketCap
          ? _value.marketCap
          : marketCap // ignore: cast_nullable_to_non_nullable
              as int,
      marketCapRank: freezed == marketCapRank
          ? _value.marketCapRank
          : marketCapRank // ignore: cast_nullable_to_non_nullable
              as int?,
      fullyDilutedValuation: freezed == fullyDilutedValuation
          ? _value.fullyDilutedValuation
          : fullyDilutedValuation // ignore: cast_nullable_to_non_nullable
              as int?,
      totalVolume: freezed == totalVolume
          ? _value.totalVolume
          : totalVolume // ignore: cast_nullable_to_non_nullable
              as double?,
      high24H: freezed == high24H
          ? _value.high24H
          : high24H // ignore: cast_nullable_to_non_nullable
              as double?,
      low24H: freezed == low24H
          ? _value.low24H
          : low24H // ignore: cast_nullable_to_non_nullable
              as double?,
      priceChange: freezed == priceChange
          ? _value.priceChange
          : priceChange // ignore: cast_nullable_to_non_nullable
              as double?,
      priceChangePercentage: null == priceChangePercentage
          ? _value.priceChangePercentage
          : priceChangePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      marketCapChange24H: freezed == marketCapChange24H
          ? _value.marketCapChange24H
          : marketCapChange24H // ignore: cast_nullable_to_non_nullable
              as double?,
      marketCapChangePercentage24H: freezed == marketCapChangePercentage24H
          ? _value.marketCapChangePercentage24H
          : marketCapChangePercentage24H // ignore: cast_nullable_to_non_nullable
              as double?,
      circulatingSupply: freezed == circulatingSupply
          ? _value.circulatingSupply
          : circulatingSupply // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSupply: freezed == totalSupply
          ? _value.totalSupply
          : totalSupply // ignore: cast_nullable_to_non_nullable
              as double?,
      maxSupply: freezed == maxSupply
          ? _value.maxSupply
          : maxSupply // ignore: cast_nullable_to_non_nullable
              as double?,
      ath: freezed == ath
          ? _value.ath
          : ath // ignore: cast_nullable_to_non_nullable
              as double?,
      athChangePercentage: freezed == athChangePercentage
          ? _value.athChangePercentage
          : athChangePercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      athDate: freezed == athDate
          ? _value.athDate
          : athDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      atl: freezed == atl
          ? _value.atl
          : atl // ignore: cast_nullable_to_non_nullable
              as double?,
      atlChangePercentage: freezed == atlChangePercentage
          ? _value.atlChangePercentage
          : atlChangePercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      atlDate: freezed == atlDate
          ? _value.atlDate
          : atlDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      lastUpdated: freezed == lastUpdated
          ? _value.lastUpdated
          : lastUpdated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MarketModel implements _MarketModel {
  const _$_MarketModel(
      {required this.id,
      required this.symbol,
      required this.name,
      required this.image,
      required this.currentPrice,
      required this.marketCap,
      this.marketCapRank,
      this.fullyDilutedValuation,
      this.totalVolume,
      this.high24H,
      this.low24H,
      @JsonKey(name: 'price_change_24h')
          this.priceChange,
      @JsonKey(name: 'price_change_percentage_24h')
          required this.priceChangePercentage,
      this.marketCapChange24H,
      this.marketCapChangePercentage24H,
      this.circulatingSupply,
      this.totalSupply,
      this.maxSupply,
      this.ath,
      this.athChangePercentage,
      this.athDate,
      this.atl,
      this.atlChangePercentage,
      this.atlDate,
      this.lastUpdated});

  factory _$_MarketModel.fromJson(Map<String, dynamic> json) =>
      _$$_MarketModelFromJson(json);

  @override
  final String id;
  @override
  final String symbol;
  @override
  final String name;
  @override
  final String image;
  @override
  final double currentPrice;
  @override
  final int marketCap;
  @override
  final int? marketCapRank;
  @override
  final int? fullyDilutedValuation;
  @override
  final double? totalVolume;
  @override
  final double? high24H;
  @override
  final double? low24H;
  @override
  @JsonKey(name: 'price_change_24h')
  final double? priceChange;
  @override
  @JsonKey(name: 'price_change_percentage_24h')
  final double priceChangePercentage;
  @override
  final double? marketCapChange24H;
  @override
  final double? marketCapChangePercentage24H;
  @override
  final double? circulatingSupply;
  @override
  final double? totalSupply;
  @override
  final double? maxSupply;
  @override
  final double? ath;
  @override
  final double? athChangePercentage;
  @override
  final DateTime? athDate;
  @override
  final double? atl;
  @override
  final double? atlChangePercentage;
  @override
  final DateTime? atlDate;
  @override
  final DateTime? lastUpdated;

  @override
  String toString() {
    return 'MarketModel(id: $id, symbol: $symbol, name: $name, image: $image, currentPrice: $currentPrice, marketCap: $marketCap, marketCapRank: $marketCapRank, fullyDilutedValuation: $fullyDilutedValuation, totalVolume: $totalVolume, high24H: $high24H, low24H: $low24H, priceChange: $priceChange, priceChangePercentage: $priceChangePercentage, marketCapChange24H: $marketCapChange24H, marketCapChangePercentage24H: $marketCapChangePercentage24H, circulatingSupply: $circulatingSupply, totalSupply: $totalSupply, maxSupply: $maxSupply, ath: $ath, athChangePercentage: $athChangePercentage, athDate: $athDate, atl: $atl, atlChangePercentage: $atlChangePercentage, atlDate: $atlDate, lastUpdated: $lastUpdated)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MarketModel &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.symbol, symbol) || other.symbol == symbol) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.currentPrice, currentPrice) ||
                other.currentPrice == currentPrice) &&
            (identical(other.marketCap, marketCap) ||
                other.marketCap == marketCap) &&
            (identical(other.marketCapRank, marketCapRank) ||
                other.marketCapRank == marketCapRank) &&
            (identical(other.fullyDilutedValuation, fullyDilutedValuation) ||
                other.fullyDilutedValuation == fullyDilutedValuation) &&
            (identical(other.totalVolume, totalVolume) ||
                other.totalVolume == totalVolume) &&
            (identical(other.high24H, high24H) || other.high24H == high24H) &&
            (identical(other.low24H, low24H) || other.low24H == low24H) &&
            (identical(other.priceChange, priceChange) ||
                other.priceChange == priceChange) &&
            (identical(other.priceChangePercentage, priceChangePercentage) ||
                other.priceChangePercentage == priceChangePercentage) &&
            (identical(other.marketCapChange24H, marketCapChange24H) ||
                other.marketCapChange24H == marketCapChange24H) &&
            (identical(other.marketCapChangePercentage24H,
                    marketCapChangePercentage24H) ||
                other.marketCapChangePercentage24H ==
                    marketCapChangePercentage24H) &&
            (identical(other.circulatingSupply, circulatingSupply) ||
                other.circulatingSupply == circulatingSupply) &&
            (identical(other.totalSupply, totalSupply) ||
                other.totalSupply == totalSupply) &&
            (identical(other.maxSupply, maxSupply) ||
                other.maxSupply == maxSupply) &&
            (identical(other.ath, ath) || other.ath == ath) &&
            (identical(other.athChangePercentage, athChangePercentage) ||
                other.athChangePercentage == athChangePercentage) &&
            (identical(other.athDate, athDate) || other.athDate == athDate) &&
            (identical(other.atl, atl) || other.atl == atl) &&
            (identical(other.atlChangePercentage, atlChangePercentage) ||
                other.atlChangePercentage == atlChangePercentage) &&
            (identical(other.atlDate, atlDate) || other.atlDate == atlDate) &&
            (identical(other.lastUpdated, lastUpdated) ||
                other.lastUpdated == lastUpdated));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        symbol,
        name,
        image,
        currentPrice,
        marketCap,
        marketCapRank,
        fullyDilutedValuation,
        totalVolume,
        high24H,
        low24H,
        priceChange,
        priceChangePercentage,
        marketCapChange24H,
        marketCapChangePercentage24H,
        circulatingSupply,
        totalSupply,
        maxSupply,
        ath,
        athChangePercentage,
        athDate,
        atl,
        atlChangePercentage,
        atlDate,
        lastUpdated
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MarketModelCopyWith<_$_MarketModel> get copyWith =>
      __$$_MarketModelCopyWithImpl<_$_MarketModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MarketModelToJson(
      this,
    );
  }
}

abstract class _MarketModel implements MarketModel {
  const factory _MarketModel(
      {required final String id,
      required final String symbol,
      required final String name,
      required final String image,
      required final double currentPrice,
      required final int marketCap,
      final int? marketCapRank,
      final int? fullyDilutedValuation,
      final double? totalVolume,
      final double? high24H,
      final double? low24H,
      @JsonKey(name: 'price_change_24h')
          final double? priceChange,
      @JsonKey(name: 'price_change_percentage_24h')
          required final double priceChangePercentage,
      final double? marketCapChange24H,
      final double? marketCapChangePercentage24H,
      final double? circulatingSupply,
      final double? totalSupply,
      final double? maxSupply,
      final double? ath,
      final double? athChangePercentage,
      final DateTime? athDate,
      final double? atl,
      final double? atlChangePercentage,
      final DateTime? atlDate,
      final DateTime? lastUpdated}) = _$_MarketModel;

  factory _MarketModel.fromJson(Map<String, dynamic> json) =
      _$_MarketModel.fromJson;

  @override
  String get id;
  @override
  String get symbol;
  @override
  String get name;
  @override
  String get image;
  @override
  double get currentPrice;
  @override
  int get marketCap;
  @override
  int? get marketCapRank;
  @override
  int? get fullyDilutedValuation;
  @override
  double? get totalVolume;
  @override
  double? get high24H;
  @override
  double? get low24H;
  @override
  @JsonKey(name: 'price_change_24h')
  double? get priceChange;
  @override
  @JsonKey(name: 'price_change_percentage_24h')
  double get priceChangePercentage;
  @override
  double? get marketCapChange24H;
  @override
  double? get marketCapChangePercentage24H;
  @override
  double? get circulatingSupply;
  @override
  double? get totalSupply;
  @override
  double? get maxSupply;
  @override
  double? get ath;
  @override
  double? get athChangePercentage;
  @override
  DateTime? get athDate;
  @override
  double? get atl;
  @override
  double? get atlChangePercentage;
  @override
  DateTime? get atlDate;
  @override
  DateTime? get lastUpdated;
  @override
  @JsonKey(ignore: true)
  _$$_MarketModelCopyWith<_$_MarketModel> get copyWith =>
      throw _privateConstructorUsedError;
}
