// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'repository_url.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RepositoryUrlModel _$RepositoryUrlModelFromJson(Map<String, dynamic> json) {
  return _RepositoryUrlModel.fromJson(json);
}

/// @nodoc
mixin _$RepositoryUrlModel {
  List<String>? get github => throw _privateConstructorUsedError;
  List<String>? get bitbucket => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RepositoryUrlModelCopyWith<RepositoryUrlModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RepositoryUrlModelCopyWith<$Res> {
  factory $RepositoryUrlModelCopyWith(
          RepositoryUrlModel value, $Res Function(RepositoryUrlModel) then) =
      _$RepositoryUrlModelCopyWithImpl<$Res, RepositoryUrlModel>;
  @useResult
  $Res call({List<String>? github, List<String>? bitbucket});
}

/// @nodoc
class _$RepositoryUrlModelCopyWithImpl<$Res, $Val extends RepositoryUrlModel>
    implements $RepositoryUrlModelCopyWith<$Res> {
  _$RepositoryUrlModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? github = freezed,
    Object? bitbucket = freezed,
  }) {
    return _then(_value.copyWith(
      github: freezed == github
          ? _value.github
          : github // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      bitbucket: freezed == bitbucket
          ? _value.bitbucket
          : bitbucket // ignore: cast_nullable_to_non_nullable
              as List<String>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_RepositoryUrlModelCopyWith<$Res>
    implements $RepositoryUrlModelCopyWith<$Res> {
  factory _$$_RepositoryUrlModelCopyWith(_$_RepositoryUrlModel value,
          $Res Function(_$_RepositoryUrlModel) then) =
      __$$_RepositoryUrlModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<String>? github, List<String>? bitbucket});
}

/// @nodoc
class __$$_RepositoryUrlModelCopyWithImpl<$Res>
    extends _$RepositoryUrlModelCopyWithImpl<$Res, _$_RepositoryUrlModel>
    implements _$$_RepositoryUrlModelCopyWith<$Res> {
  __$$_RepositoryUrlModelCopyWithImpl(
      _$_RepositoryUrlModel _value, $Res Function(_$_RepositoryUrlModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? github = freezed,
    Object? bitbucket = freezed,
  }) {
    return _then(_$_RepositoryUrlModel(
      github: freezed == github
          ? _value._github
          : github // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      bitbucket: freezed == bitbucket
          ? _value._bitbucket
          : bitbucket // ignore: cast_nullable_to_non_nullable
              as List<String>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_RepositoryUrlModel implements _RepositoryUrlModel {
  const _$_RepositoryUrlModel(
      {final List<String>? github, final List<String>? bitbucket})
      : _github = github,
        _bitbucket = bitbucket;

  factory _$_RepositoryUrlModel.fromJson(Map<String, dynamic> json) =>
      _$$_RepositoryUrlModelFromJson(json);

  final List<String>? _github;
  @override
  List<String>? get github {
    final value = _github;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<String>? _bitbucket;
  @override
  List<String>? get bitbucket {
    final value = _bitbucket;
    if (value == null) return null;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'RepositoryUrlModel(github: $github, bitbucket: $bitbucket)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_RepositoryUrlModel &&
            const DeepCollectionEquality().equals(other._github, _github) &&
            const DeepCollectionEquality()
                .equals(other._bitbucket, _bitbucket));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_github),
      const DeepCollectionEquality().hash(_bitbucket));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_RepositoryUrlModelCopyWith<_$_RepositoryUrlModel> get copyWith =>
      __$$_RepositoryUrlModelCopyWithImpl<_$_RepositoryUrlModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_RepositoryUrlModelToJson(
      this,
    );
  }
}

abstract class _RepositoryUrlModel implements RepositoryUrlModel {
  const factory _RepositoryUrlModel(
      {final List<String>? github,
      final List<String>? bitbucket}) = _$_RepositoryUrlModel;

  factory _RepositoryUrlModel.fromJson(Map<String, dynamic> json) =
      _$_RepositoryUrlModel.fromJson;

  @override
  List<String>? get github;
  @override
  List<String>? get bitbucket;
  @override
  @JsonKey(ignore: true)
  _$$_RepositoryUrlModelCopyWith<_$_RepositoryUrlModel> get copyWith =>
      throw _privateConstructorUsedError;
}
