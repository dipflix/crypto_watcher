// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'repository_url.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_RepositoryUrlModel _$$_RepositoryUrlModelFromJson(Map json) =>
    _$_RepositoryUrlModel(
      github:
          (json['github'] as List<dynamic>?)?.map((e) => e as String).toList(),
      bitbucket: (json['bitbucket'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$$_RepositoryUrlModelToJson(
        _$_RepositoryUrlModel instance) =>
    <String, dynamic>{
      'github': instance.github,
      'bitbucket': instance.bitbucket,
    };
