// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'ticker.model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

TickerModel _$TickerModelFromJson(Map<String, dynamic> json) {
  return _TickerModel.fromJson(json);
}

/// @nodoc
mixin _$TickerModel {
  String get base => throw _privateConstructorUsedError;
  String get target => throw _privateConstructorUsedError;
  MarketModel get market => throw _privateConstructorUsedError;
  double get last => throw _privateConstructorUsedError;
  double get volume => throw _privateConstructorUsedError;
  Map<String, double> get convertedLast => throw _privateConstructorUsedError;
  Map<String, double> get convertedVolume => throw _privateConstructorUsedError;
  String get trustScore => throw _privateConstructorUsedError;
  double get bidAskSpreadPercentage => throw _privateConstructorUsedError;
  DateTime get timestamp => throw _privateConstructorUsedError;
  DateTime get lastTradedAt => throw _privateConstructorUsedError;
  DateTime get lastFetchAt => throw _privateConstructorUsedError;
  bool get isAnomaly => throw _privateConstructorUsedError;
  bool get isStale => throw _privateConstructorUsedError;
  String get tradeUrl => throw _privateConstructorUsedError;
  String? get tokenInfoUrl => throw _privateConstructorUsedError;
  String get coinId => throw _privateConstructorUsedError;
  String get targetCoinId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TickerModelCopyWith<TickerModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TickerModelCopyWith<$Res> {
  factory $TickerModelCopyWith(
          TickerModel value, $Res Function(TickerModel) then) =
      _$TickerModelCopyWithImpl<$Res, TickerModel>;
  @useResult
  $Res call(
      {String base,
      String target,
      MarketModel market,
      double last,
      double volume,
      Map<String, double> convertedLast,
      Map<String, double> convertedVolume,
      String trustScore,
      double bidAskSpreadPercentage,
      DateTime timestamp,
      DateTime lastTradedAt,
      DateTime lastFetchAt,
      bool isAnomaly,
      bool isStale,
      String tradeUrl,
      String? tokenInfoUrl,
      String coinId,
      String targetCoinId});

  $MarketModelCopyWith<$Res> get market;
}

/// @nodoc
class _$TickerModelCopyWithImpl<$Res, $Val extends TickerModel>
    implements $TickerModelCopyWith<$Res> {
  _$TickerModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? base = null,
    Object? target = null,
    Object? market = null,
    Object? last = null,
    Object? volume = null,
    Object? convertedLast = null,
    Object? convertedVolume = null,
    Object? trustScore = null,
    Object? bidAskSpreadPercentage = null,
    Object? timestamp = null,
    Object? lastTradedAt = null,
    Object? lastFetchAt = null,
    Object? isAnomaly = null,
    Object? isStale = null,
    Object? tradeUrl = null,
    Object? tokenInfoUrl = freezed,
    Object? coinId = null,
    Object? targetCoinId = null,
  }) {
    return _then(_value.copyWith(
      base: null == base
          ? _value.base
          : base // ignore: cast_nullable_to_non_nullable
              as String,
      target: null == target
          ? _value.target
          : target // ignore: cast_nullable_to_non_nullable
              as String,
      market: null == market
          ? _value.market
          : market // ignore: cast_nullable_to_non_nullable
              as MarketModel,
      last: null == last
          ? _value.last
          : last // ignore: cast_nullable_to_non_nullable
              as double,
      volume: null == volume
          ? _value.volume
          : volume // ignore: cast_nullable_to_non_nullable
              as double,
      convertedLast: null == convertedLast
          ? _value.convertedLast
          : convertedLast // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      convertedVolume: null == convertedVolume
          ? _value.convertedVolume
          : convertedVolume // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      trustScore: null == trustScore
          ? _value.trustScore
          : trustScore // ignore: cast_nullable_to_non_nullable
              as String,
      bidAskSpreadPercentage: null == bidAskSpreadPercentage
          ? _value.bidAskSpreadPercentage
          : bidAskSpreadPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      timestamp: null == timestamp
          ? _value.timestamp
          : timestamp // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastTradedAt: null == lastTradedAt
          ? _value.lastTradedAt
          : lastTradedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastFetchAt: null == lastFetchAt
          ? _value.lastFetchAt
          : lastFetchAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isAnomaly: null == isAnomaly
          ? _value.isAnomaly
          : isAnomaly // ignore: cast_nullable_to_non_nullable
              as bool,
      isStale: null == isStale
          ? _value.isStale
          : isStale // ignore: cast_nullable_to_non_nullable
              as bool,
      tradeUrl: null == tradeUrl
          ? _value.tradeUrl
          : tradeUrl // ignore: cast_nullable_to_non_nullable
              as String,
      tokenInfoUrl: freezed == tokenInfoUrl
          ? _value.tokenInfoUrl
          : tokenInfoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      coinId: null == coinId
          ? _value.coinId
          : coinId // ignore: cast_nullable_to_non_nullable
              as String,
      targetCoinId: null == targetCoinId
          ? _value.targetCoinId
          : targetCoinId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MarketModelCopyWith<$Res> get market {
    return $MarketModelCopyWith<$Res>(_value.market, (value) {
      return _then(_value.copyWith(market: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_TickerModelCopyWith<$Res>
    implements $TickerModelCopyWith<$Res> {
  factory _$$_TickerModelCopyWith(
          _$_TickerModel value, $Res Function(_$_TickerModel) then) =
      __$$_TickerModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String base,
      String target,
      MarketModel market,
      double last,
      double volume,
      Map<String, double> convertedLast,
      Map<String, double> convertedVolume,
      String trustScore,
      double bidAskSpreadPercentage,
      DateTime timestamp,
      DateTime lastTradedAt,
      DateTime lastFetchAt,
      bool isAnomaly,
      bool isStale,
      String tradeUrl,
      String? tokenInfoUrl,
      String coinId,
      String targetCoinId});

  @override
  $MarketModelCopyWith<$Res> get market;
}

/// @nodoc
class __$$_TickerModelCopyWithImpl<$Res>
    extends _$TickerModelCopyWithImpl<$Res, _$_TickerModel>
    implements _$$_TickerModelCopyWith<$Res> {
  __$$_TickerModelCopyWithImpl(
      _$_TickerModel _value, $Res Function(_$_TickerModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? base = null,
    Object? target = null,
    Object? market = null,
    Object? last = null,
    Object? volume = null,
    Object? convertedLast = null,
    Object? convertedVolume = null,
    Object? trustScore = null,
    Object? bidAskSpreadPercentage = null,
    Object? timestamp = null,
    Object? lastTradedAt = null,
    Object? lastFetchAt = null,
    Object? isAnomaly = null,
    Object? isStale = null,
    Object? tradeUrl = null,
    Object? tokenInfoUrl = freezed,
    Object? coinId = null,
    Object? targetCoinId = null,
  }) {
    return _then(_$_TickerModel(
      base: null == base
          ? _value.base
          : base // ignore: cast_nullable_to_non_nullable
              as String,
      target: null == target
          ? _value.target
          : target // ignore: cast_nullable_to_non_nullable
              as String,
      market: null == market
          ? _value.market
          : market // ignore: cast_nullable_to_non_nullable
              as MarketModel,
      last: null == last
          ? _value.last
          : last // ignore: cast_nullable_to_non_nullable
              as double,
      volume: null == volume
          ? _value.volume
          : volume // ignore: cast_nullable_to_non_nullable
              as double,
      convertedLast: null == convertedLast
          ? _value._convertedLast
          : convertedLast // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      convertedVolume: null == convertedVolume
          ? _value._convertedVolume
          : convertedVolume // ignore: cast_nullable_to_non_nullable
              as Map<String, double>,
      trustScore: null == trustScore
          ? _value.trustScore
          : trustScore // ignore: cast_nullable_to_non_nullable
              as String,
      bidAskSpreadPercentage: null == bidAskSpreadPercentage
          ? _value.bidAskSpreadPercentage
          : bidAskSpreadPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      timestamp: null == timestamp
          ? _value.timestamp
          : timestamp // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastTradedAt: null == lastTradedAt
          ? _value.lastTradedAt
          : lastTradedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastFetchAt: null == lastFetchAt
          ? _value.lastFetchAt
          : lastFetchAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isAnomaly: null == isAnomaly
          ? _value.isAnomaly
          : isAnomaly // ignore: cast_nullable_to_non_nullable
              as bool,
      isStale: null == isStale
          ? _value.isStale
          : isStale // ignore: cast_nullable_to_non_nullable
              as bool,
      tradeUrl: null == tradeUrl
          ? _value.tradeUrl
          : tradeUrl // ignore: cast_nullable_to_non_nullable
              as String,
      tokenInfoUrl: freezed == tokenInfoUrl
          ? _value.tokenInfoUrl
          : tokenInfoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      coinId: null == coinId
          ? _value.coinId
          : coinId // ignore: cast_nullable_to_non_nullable
              as String,
      targetCoinId: null == targetCoinId
          ? _value.targetCoinId
          : targetCoinId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_TickerModel implements _TickerModel {
  const _$_TickerModel(
      {required this.base,
      required this.target,
      required this.market,
      required this.last,
      required this.volume,
      required final Map<String, double> convertedLast,
      required final Map<String, double> convertedVolume,
      required this.trustScore,
      required this.bidAskSpreadPercentage,
      required this.timestamp,
      required this.lastTradedAt,
      required this.lastFetchAt,
      required this.isAnomaly,
      required this.isStale,
      required this.tradeUrl,
      this.tokenInfoUrl,
      required this.coinId,
      required this.targetCoinId})
      : _convertedLast = convertedLast,
        _convertedVolume = convertedVolume;

  factory _$_TickerModel.fromJson(Map<String, dynamic> json) =>
      _$$_TickerModelFromJson(json);

  @override
  final String base;
  @override
  final String target;
  @override
  final MarketModel market;
  @override
  final double last;
  @override
  final double volume;
  final Map<String, double> _convertedLast;
  @override
  Map<String, double> get convertedLast {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_convertedLast);
  }

  final Map<String, double> _convertedVolume;
  @override
  Map<String, double> get convertedVolume {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_convertedVolume);
  }

  @override
  final String trustScore;
  @override
  final double bidAskSpreadPercentage;
  @override
  final DateTime timestamp;
  @override
  final DateTime lastTradedAt;
  @override
  final DateTime lastFetchAt;
  @override
  final bool isAnomaly;
  @override
  final bool isStale;
  @override
  final String tradeUrl;
  @override
  final String? tokenInfoUrl;
  @override
  final String coinId;
  @override
  final String targetCoinId;

  @override
  String toString() {
    return 'TickerModel(base: $base, target: $target, market: $market, last: $last, volume: $volume, convertedLast: $convertedLast, convertedVolume: $convertedVolume, trustScore: $trustScore, bidAskSpreadPercentage: $bidAskSpreadPercentage, timestamp: $timestamp, lastTradedAt: $lastTradedAt, lastFetchAt: $lastFetchAt, isAnomaly: $isAnomaly, isStale: $isStale, tradeUrl: $tradeUrl, tokenInfoUrl: $tokenInfoUrl, coinId: $coinId, targetCoinId: $targetCoinId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_TickerModel &&
            (identical(other.base, base) || other.base == base) &&
            (identical(other.target, target) || other.target == target) &&
            (identical(other.market, market) || other.market == market) &&
            (identical(other.last, last) || other.last == last) &&
            (identical(other.volume, volume) || other.volume == volume) &&
            const DeepCollectionEquality()
                .equals(other._convertedLast, _convertedLast) &&
            const DeepCollectionEquality()
                .equals(other._convertedVolume, _convertedVolume) &&
            (identical(other.trustScore, trustScore) ||
                other.trustScore == trustScore) &&
            (identical(other.bidAskSpreadPercentage, bidAskSpreadPercentage) ||
                other.bidAskSpreadPercentage == bidAskSpreadPercentage) &&
            (identical(other.timestamp, timestamp) ||
                other.timestamp == timestamp) &&
            (identical(other.lastTradedAt, lastTradedAt) ||
                other.lastTradedAt == lastTradedAt) &&
            (identical(other.lastFetchAt, lastFetchAt) ||
                other.lastFetchAt == lastFetchAt) &&
            (identical(other.isAnomaly, isAnomaly) ||
                other.isAnomaly == isAnomaly) &&
            (identical(other.isStale, isStale) || other.isStale == isStale) &&
            (identical(other.tradeUrl, tradeUrl) ||
                other.tradeUrl == tradeUrl) &&
            (identical(other.tokenInfoUrl, tokenInfoUrl) ||
                other.tokenInfoUrl == tokenInfoUrl) &&
            (identical(other.coinId, coinId) || other.coinId == coinId) &&
            (identical(other.targetCoinId, targetCoinId) ||
                other.targetCoinId == targetCoinId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      base,
      target,
      market,
      last,
      volume,
      const DeepCollectionEquality().hash(_convertedLast),
      const DeepCollectionEquality().hash(_convertedVolume),
      trustScore,
      bidAskSpreadPercentage,
      timestamp,
      lastTradedAt,
      lastFetchAt,
      isAnomaly,
      isStale,
      tradeUrl,
      tokenInfoUrl,
      coinId,
      targetCoinId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_TickerModelCopyWith<_$_TickerModel> get copyWith =>
      __$$_TickerModelCopyWithImpl<_$_TickerModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_TickerModelToJson(
      this,
    );
  }
}

abstract class _TickerModel implements TickerModel {
  const factory _TickerModel(
      {required final String base,
      required final String target,
      required final MarketModel market,
      required final double last,
      required final double volume,
      required final Map<String, double> convertedLast,
      required final Map<String, double> convertedVolume,
      required final String trustScore,
      required final double bidAskSpreadPercentage,
      required final DateTime timestamp,
      required final DateTime lastTradedAt,
      required final DateTime lastFetchAt,
      required final bool isAnomaly,
      required final bool isStale,
      required final String tradeUrl,
      final String? tokenInfoUrl,
      required final String coinId,
      required final String targetCoinId}) = _$_TickerModel;

  factory _TickerModel.fromJson(Map<String, dynamic> json) =
      _$_TickerModel.fromJson;

  @override
  String get base;
  @override
  String get target;
  @override
  MarketModel get market;
  @override
  double get last;
  @override
  double get volume;
  @override
  Map<String, double> get convertedLast;
  @override
  Map<String, double> get convertedVolume;
  @override
  String get trustScore;
  @override
  double get bidAskSpreadPercentage;
  @override
  DateTime get timestamp;
  @override
  DateTime get lastTradedAt;
  @override
  DateTime get lastFetchAt;
  @override
  bool get isAnomaly;
  @override
  bool get isStale;
  @override
  String get tradeUrl;
  @override
  String? get tokenInfoUrl;
  @override
  String get coinId;
  @override
  String get targetCoinId;
  @override
  @JsonKey(ignore: true)
  _$$_TickerModelCopyWith<_$_TickerModel> get copyWith =>
      throw _privateConstructorUsedError;
}
