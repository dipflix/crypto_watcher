// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticker.model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_TickerModel _$$_TickerModelFromJson(Map json) => _$_TickerModel(
      base: json['base'] as String,
      target: json['target'] as String,
      market: MarketModel.fromJson(
          Map<String, dynamic>.from(json['market'] as Map)),
      last: (json['last'] as num).toDouble(),
      volume: (json['volume'] as num).toDouble(),
      convertedLast: (json['converted_last'] as Map).map(
        (k, e) => MapEntry(k as String, (e as num).toDouble()),
      ),
      convertedVolume: (json['converted_volume'] as Map).map(
        (k, e) => MapEntry(k as String, (e as num).toDouble()),
      ),
      trustScore: json['trust_score'] as String,
      bidAskSpreadPercentage:
          (json['bid_ask_spread_percentage'] as num).toDouble(),
      timestamp: DateTime.parse(json['timestamp'] as String),
      lastTradedAt: DateTime.parse(json['last_traded_at'] as String),
      lastFetchAt: DateTime.parse(json['last_fetch_at'] as String),
      isAnomaly: json['is_anomaly'] as bool,
      isStale: json['is_stale'] as bool,
      tradeUrl: json['trade_url'] as String,
      tokenInfoUrl: json['token_info_url'] as String?,
      coinId: json['coin_id'] as String,
      targetCoinId: json['target_coin_id'] as String,
    );

Map<String, dynamic> _$$_TickerModelToJson(_$_TickerModel instance) =>
    <String, dynamic>{
      'base': instance.base,
      'target': instance.target,
      'market': instance.market,
      'last': instance.last,
      'volume': instance.volume,
      'converted_last': instance.convertedLast,
      'converted_volume': instance.convertedVolume,
      'trust_score': instance.trustScore,
      'bid_ask_spread_percentage': instance.bidAskSpreadPercentage,
      'timestamp': instance.timestamp.toIso8601String(),
      'last_traded_at': instance.lastTradedAt.toIso8601String(),
      'last_fetch_at': instance.lastFetchAt.toIso8601String(),
      'is_anomaly': instance.isAnomaly,
      'is_stale': instance.isStale,
      'trade_url': instance.tradeUrl,
      'token_info_url': instance.tokenInfoUrl,
      'coin_id': instance.coinId,
      'target_coin_id': instance.targetCoinId,
    };
