// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'image_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ImageState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Color background, Image image) ready,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Color background, Image image)? ready,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Color background, Image image)? ready,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ImageState_Loading value) loading,
    required TResult Function(ImageState_Ready value) ready,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ImageState_Loading value)? loading,
    TResult? Function(ImageState_Ready value)? ready,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ImageState_Loading value)? loading,
    TResult Function(ImageState_Ready value)? ready,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ImageStateCopyWith<$Res> {
  factory $ImageStateCopyWith(
          ImageState value, $Res Function(ImageState) then) =
      _$ImageStateCopyWithImpl<$Res, ImageState>;
}

/// @nodoc
class _$ImageStateCopyWithImpl<$Res, $Val extends ImageState>
    implements $ImageStateCopyWith<$Res> {
  _$ImageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ImageState_LoadingCopyWith<$Res> {
  factory _$$ImageState_LoadingCopyWith(_$ImageState_Loading value,
          $Res Function(_$ImageState_Loading) then) =
      __$$ImageState_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ImageState_LoadingCopyWithImpl<$Res>
    extends _$ImageStateCopyWithImpl<$Res, _$ImageState_Loading>
    implements _$$ImageState_LoadingCopyWith<$Res> {
  __$$ImageState_LoadingCopyWithImpl(
      _$ImageState_Loading _value, $Res Function(_$ImageState_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ImageState_Loading implements ImageState_Loading {
  const _$ImageState_Loading();

  @override
  String toString() {
    return 'ImageState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ImageState_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Color background, Image image) ready,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Color background, Image image)? ready,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Color background, Image image)? ready,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ImageState_Loading value) loading,
    required TResult Function(ImageState_Ready value) ready,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ImageState_Loading value)? loading,
    TResult? Function(ImageState_Ready value)? ready,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ImageState_Loading value)? loading,
    TResult Function(ImageState_Ready value)? ready,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class ImageState_Loading implements ImageState {
  const factory ImageState_Loading() = _$ImageState_Loading;
}

/// @nodoc
abstract class _$$ImageState_ReadyCopyWith<$Res> {
  factory _$$ImageState_ReadyCopyWith(
          _$ImageState_Ready value, $Res Function(_$ImageState_Ready) then) =
      __$$ImageState_ReadyCopyWithImpl<$Res>;
  @useResult
  $Res call({Color background, Image image});
}

/// @nodoc
class __$$ImageState_ReadyCopyWithImpl<$Res>
    extends _$ImageStateCopyWithImpl<$Res, _$ImageState_Ready>
    implements _$$ImageState_ReadyCopyWith<$Res> {
  __$$ImageState_ReadyCopyWithImpl(
      _$ImageState_Ready _value, $Res Function(_$ImageState_Ready) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? background = null,
    Object? image = null,
  }) {
    return _then(_$ImageState_Ready(
      background: null == background
          ? _value.background
          : background // ignore: cast_nullable_to_non_nullable
              as Color,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as Image,
    ));
  }
}

/// @nodoc

class _$ImageState_Ready implements ImageState_Ready {
  const _$ImageState_Ready({required this.background, required this.image});

  @override
  final Color background;
  @override
  final Image image;

  @override
  String toString() {
    return 'ImageState.ready(background: $background, image: $image)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ImageState_Ready &&
            (identical(other.background, background) ||
                other.background == background) &&
            (identical(other.image, image) || other.image == image));
  }

  @override
  int get hashCode => Object.hash(runtimeType, background, image);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ImageState_ReadyCopyWith<_$ImageState_Ready> get copyWith =>
      __$$ImageState_ReadyCopyWithImpl<_$ImageState_Ready>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loading,
    required TResult Function(Color background, Image image) ready,
  }) {
    return ready(background, image);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loading,
    TResult? Function(Color background, Image image)? ready,
  }) {
    return ready?.call(background, image);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loading,
    TResult Function(Color background, Image image)? ready,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(background, image);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ImageState_Loading value) loading,
    required TResult Function(ImageState_Ready value) ready,
  }) {
    return ready(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ImageState_Loading value)? loading,
    TResult? Function(ImageState_Ready value)? ready,
  }) {
    return ready?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ImageState_Loading value)? loading,
    TResult Function(ImageState_Ready value)? ready,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(this);
    }
    return orElse();
  }
}

abstract class ImageState_Ready implements ImageState {
  const factory ImageState_Ready(
      {required final Color background,
      required final Image image}) = _$ImageState_Ready;

  Color get background;
  Image get image;
  @JsonKey(ignore: true)
  _$$ImageState_ReadyCopyWith<_$ImageState_Ready> get copyWith =>
      throw _privateConstructorUsedError;
}
