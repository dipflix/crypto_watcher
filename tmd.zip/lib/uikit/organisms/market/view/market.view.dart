import 'dart:async';
import 'dart:math' as math;
import 'package:crypto_watcher/di/injector.dart';
import 'package:crypto_watcher/router/router.gr.dart';
import 'package:crypto_watcher/shared/models/market/market.model.dart';
import 'package:crypto_watcher/uikit/organisms/market/view/cubit/image_cubit.dart';
import 'package:crypto_watcher/uikit/uikit.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class MarketView extends StatelessWidget {
  final MarketModel model;
  late final ImageCubit imageCubit;

  MarketView({
    Key? key,
    required this.model,
  }) : super(key: key) {
    imageCubit = ImageCubit(image)..process();
  }

  late Image image = Image.network(model.image);

  final AppRouter appRouter = getIt<AppRouter>();

  @override
  Widget build(BuildContext context) {
    return FlattedCard(
      child: InkWell(
        onTap: () {
          appRouter.push(CoinDetailRoute(model: model));
        },
        borderRadius: BorderRadius.circular(17),
        excludeFromSemantics: true,
        child: Semantics(
          label: model.name,
          child: SizedBox(
            height: 85.h,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: _buildImage()),
                  Gap.vertical.regular(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextBody.bold(
                        model.name.length > 12
                            ? model.name.replaceRange(
                                12,
                                model.name.length,
                                '...',
                              )
                            : model.name,
                        fontSize: FontSize.body.sp,
                      ),
                      TextBody.thin(
                        '${model.symbol.toUpperCase()}',
                        fontSize: FontSize.caption,
                      ),
                    ],
                  ),
                  Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextBody.bold(
                        '${model.currentPrice.toStringAsFixed(2)} ${'usd'.toUpperCase()}',
                        fontSize: FontSize.h4.sp,
                      ),
                      Spacer(),
                      PricePercentageCaption(
                        percentage: model.priceChangePercentage,
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildImage() {
    return BlocBuilder<ImageCubit, ImageState>(
      bloc: imageCubit,
      builder: (context, state) {
        return state.when(loading: () {
          return DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Palette.overlay2,
            ),
            child: SizedBox.square(
              dimension: 55.w,
            ),
          );
        }, ready: (color, image) {
          return DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: color.withOpacity(0.25),
            ),
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: SizedBox.square(
                dimension: 48.w,
                child: Center(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: ImageNetwork(
                      model.image,
                      width: 42.w,
                      height: 42.h,
                    ),
                  ),
                ),
              ),
            ),
          );
        });
      },
    );
  }
}

class ChangePriceTriangle extends StatelessWidget {
  final num priceChangePercentage;

  const ChangePriceTriangle({
    required this.priceChangePercentage,
  });

  @override
  Widget build(BuildContext context) {
    if (priceChangePercentage > 0) {
      return Row(
        children: <Widget>[
          Icon(
            Icons.arrow_upward,
            color: Palette.success,
            size: 16,
          ),
          Text(
            '+${priceChangePercentage.toStringAsFixed(2)}%',
          ),
        ],
      );
    } else {
      if (priceChangePercentage < 0) {
        return Row(
          children: <Widget>[
            Icon(
              Icons.arrow_downward,
              color: Palette.errorRed,
              size: 16,
            ),
            Text(
              '-${priceChangePercentage.abs().toStringAsFixed(2)}%',
            ),
          ],
        );
      } else {
        return Row(
          children: <Widget>[
            Container(
              transform: Matrix4.translationValues(0, -1, 0),
              child: Transform.rotate(
                angle: 90 * math.pi / 180,
                child: Icon(
                  Icons.play_arrow,
                  color: Palette.overlay3,
                ),
              ),
            ),
            Text(
              '${priceChangePercentage.abs().toStringAsFixed(2)}%',
            ),
          ],
        );
      }
    }
  }
}
